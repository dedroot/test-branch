#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ __main__.py                    [ Created: 2023-01-31 | 09:20 ]  #
#                                            [ Updated: 2023-07-21 | 10:11 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The main file of GitPy, where all start                                    #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is the __main__ file of GitPy
"""


import os

from gitpy.core.cli import GitPyCLI

# cwd = os.path.dirname(os.path.abspath(__file__))


def entry_point():
    """The entry point of GitPy."""

    GitPyCLI()

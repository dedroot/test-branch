#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ generate_man_page.py           [ Created: 2023-07-07 | 17:46 ]  #
#                                            [ Updated: 2023-07-07 | 17:46 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Generate the manual page of the GitPy tool.                                #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module generate a manual page of the GitPy tool.
"""

manual_page = """.TH GitPy 1
.SH NAME
GitPy \- A Python3 tool for search and download a GitHub's repository directly in the terminal.
.SH SYNOPSIS
.B gitpy 
[--help]
[--hv]
[command]
.SH DESCRIPTION
.B GitPy This is a program that can be use to search and download a repository on GitHub using the GitHub API REST. The program was written in Python3 and designed to be use on Arch and Debian based ditros. GitPy have a main console that can be used to search and download a repository. It could also be used in a CLI environment, inspired by the Metasploit network testing tool (not yet implemented).

"""

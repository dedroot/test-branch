#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ process.py                     [ Created: 2023-02-05 | 10:45 ]  #
#                                            [ Updated: 2023-06-19 | 21:35 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Execute command and prompt the STDOUT and STDERR                           #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


import os
import signal
import time
from subprocess import PIPE, Popen, call, run

import gitpy.configs.variables as variables
from gitpy.utils.colors import Color


class Process(object):
    """
    Represents a running/ran process
    """

    @staticmethod
    def devnull():
        """
        Helper method for opening devnull
        """
        return open("/dev/null", "w")

    @staticmethod
    def call(command, cwd=None, shell=False, env=None, new_line_before=False):
        """
        Calls a command (either string or list of args).
        Returns tuple:
            (stdout, stderr)
        """

        verbose = variables.OPTION_VERBOSE
        if type(command) is not str or " " in command or shell:
            shell = True
            if verbose >= 1:
                if new_line_before is True:
                    Color.pe("\n  {&} Executing (Shell): {B}%s{W}" % command)

                else:
                    Color.pe("  {&} Executing (Shell): {B}%s{W}" % command)

        else:
            shell = False
            if verbose >= 1:
                if new_line_before is True:
                    Color.pe("\n  {&} Executing: {B}%s{W}" % command)

                else:
                    Color.pe("  {&} Executing: {B}%s{W}" % command)

        pid = Popen(command, cwd=cwd, stdout=PIPE, stderr=PIPE, shell=shell, env=env)
        pid.wait()

        (stdout, stderr) = pid.communicate()
        # Python 3 compatibility
        if type(stdout) is bytes:
            stdout = stdout.decode("utf-8")

        if type(stderr) is bytes:
            stderr = stderr.decode("utf-8")

        if verbose >= 2 and stdout is not None and stdout.strip() != "":
            Color.pl(
                "  {D}[{W}{bold}stdout{W}{D}]{W} %s{W}"
                % "\n  {D}[{W}{bold}stdout{W}{D}]{W} ".join(stdout.strip().split("\n"))
            )

        if verbose >= 2 and stderr is not None and stderr.strip() != "":
            Color.pl(
                "  {D}[{W}{R}stderr{W}{D}]{W} %s{W}"
                % "\n  {D}[{W}{R}stderr{W}{D}]{W} ".join(stderr.strip().split("\n"))
            )

        return (stdout, stderr, pid.returncode)

    @staticmethod
    def call_with_sub_run(
        command,
        cwd=None,
        shell=False,
        env=None,
        check=False,
        verbose=variables.OPTION_VERBOSE,
    ):
        if type(command) is not str or " " in command or shell:
            shell = True
            if verbose >= 1:
                Color.pe("  {&} Executing (Shell): {B}%s{W}" % command)
        else:
            shell = False
            if verbose >= 1:
                Color.pe("  {&} Executing: {B}%s{W}" % command)

        # run command with the run() function in the pid variable
        pid = run(
            command,
            cwd=cwd,
            shell=shell,
            env=env,
            universal_newlines=True,
            text=True,
            check=check,
        )

        return Color.pl("{#}%s{W}" % pid)

    @staticmethod
    def call_with_sub_call(command, cwd=None, shell=False, env=None, verbose=variables.OPTION_VERBOSE):
        if type(command) is not str or " " in command or shell:
            shell = True
            if verbose >= 1:
                Color.pe("  {&} Executing (Shell): {B}%s{W}" % command)
        else:
            shell = False
            if verbose >= 1:
                Color.pe("  {&} Executing: {B}%s{W}" % command)

        # run command with the run() function in the pid variable
        pid = call(command, cwd=cwd, shell=shell, env=env, universal_newlines=True, text=True)

        return Color.pl("{#}%s{W}" % pid)

    @staticmethod
    def exists(program, verbose=variables.OPTION_VERBOSE):
        """
        Checks if program is installed on this system
        """

        p = Process(command=f"which {program}")
        stdout = p.stdout().strip()
        stderr = p.stderr().strip()

        if (
            stdout == ""
            and stderr == ""
            or "not found" in stderr
            or "not found" in stdout
            or "no" in stderr
            or "no" in stdout
        ):
            return False

        return True

    def __init__(
        self,
        command,
        devnull=False,
        stdout=PIPE,
        stderr=PIPE,
        cwd=None,
        bufsize=0,
        stdin=PIPE,
        shell=False,
        verbose=variables.OPTION_VERBOSE,
    ):
        """
        Starts executing command
        """

        if type(command) is str:
            # Commands have to be a list
            command = command.split(" ")

        self.command = command

        if verbose >= 1:
            Color.pe("  {&} Executing: {B}%s{W}" % " ".join(command))

        self.out = None
        self.err = None
        if devnull:
            sout = Process.devnull()
            serr = Process.devnull()
        else:
            sout = stdout
            serr = stderr

        self.start_time = time.time()

        self.pid = Popen(
            command,
            stdout=sout,
            stderr=serr,
            stdin=stdin,
            cwd=cwd,
            bufsize=bufsize,
            shell=shell,
        )

    def __del__(self):
        """
        Ran when object is GC'd.
        If process is still running at this point, it should die.
        """
        try:
            if self.pid and self.pid.poll() is None:
                self.interrupt()
        except AttributeError:
            pass

    def stdout(self, verbose=variables.OPTION_VERBOSE):
        """
        Waits for process to finish, returns stdout output
        """
        self.get_output()
        if verbose >= 2 and self.out is not None and self.out.strip() != "":
            Color.pe(
                "  {D}[{W}{bold}stdout{W}{D}]{W} %s{W}"
                % "\n  {D}[{W}{bold}stdout{W}{D}]{W} ".join(self.out.strip().split("\n"))
            )
        return self.out

    def stderr(self, verbose=variables.OPTION_VERBOSE):
        """
        Waits for process to finish, returns stderr output
        """
        self.get_output()
        if verbose >= 2 and self.err is not None and self.err.strip() != "":
            Color.pl(
                "  {D}[{W}{R}stderr{W}{D}]{W} %s{W}"
                % "\n  {D}[{W}{R}stderr{W}{D}]{W} ".join(self.err.strip().split("\n"))
            )
        return self.err

    def stdoutln(self):
        return self.pid.stdout.readline()

    def stderrln(self):
        return self.pid.stderr.readline()

    def stdin(self, text):
        if self.pid.stdin:
            self.pid.stdin.write(text.encode("utf-8"))
            self.pid.stdin.flush()

    def get_output(self):
        """
        Waits for process to finish, sets stdout & stderr
        """
        if self.pid.poll() is None:
            self.pid.wait()
        if self.out is None:
            (self.out, self.err) = self.pid.communicate()

        if type(self.out) is bytes:
            self.out = self.out.decode("utf-8")

        if type(self.err) is bytes:
            self.err = self.err.decode("utf-8")

        return (self.out, self.err)

    def poll(self):
        """
        Returns exit code if process is dead, otherwise 'None'
        """
        return self.pid.poll()

    def wait(self):
        self.pid.wait()

    def running_time(self):
        """
        Returns number of seconds since process was started
        """
        return int(time.time() - self.start_time)

    def interrupt(self, wait_time=2.0, verbose=variables.OPTION_VERBOSE):
        """
        Send interrupt to current process.
        If process fails to exit within `wait_time` seconds, terminates it.
        """
        try:
            pid = self.pid.pid
            cmd = self.command
            if type(cmd) is list:
                cmd = " ".join(cmd)

            if verbose >= 1:
                Color.pe("  {&} Sending interrupt to PID %d (%s)" % (pid, cmd))

            os.kill(pid, signal.SIGINT)

            start_time = time.time()  # Time since Interrupt was sent
            while self.pid.poll() is None:
                # Process is still running
                time.sleep(0.1)
                if time.time() - start_time > wait_time:
                    # We waited too long for process to die, terminate it.
                    if verbose > 1:
                        Color.pe("\n  {&} Waited > %0.2f seconds for process to die, killing it" % wait_time)
                    os.kill(pid, signal.SIGTERM)
                    self.pid.terminate()
                    break

        except OSError as e:
            if "No such process" in e.__str__():
                return
            raise e  # process cannot be killed

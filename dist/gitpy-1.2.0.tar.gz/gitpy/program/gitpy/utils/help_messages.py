#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ help_messages.py               [ Created: 2023-02-21 | 10:26 ]  #
#                                            [ Updated: 2023-11-11 | 16:48 ]  #
# ---[Description & File Language]------------------------------------------- #
#  All help messages for GitPy                                                #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module contains all help messages for GitPy.
"""


import os

import gitpy.configs.variables as variables


class HelpMessages:
    """
    All help messages of GitPy.
    """

    try:
        gitpy_install_path = os.environ[variables.GITPY_PATH_ENV_VAR_NAME]
        gitpy_config_file_path = gitpy_install_path + "/config/gitpy_config.yml"
    except KeyError:
        gitpy_config_file_path = (
            variables.DEFAULT_GITPY_CONFIG_FILE_PATH
            + " {W}(environment variable {C}{bold}%s{W} not found)" % variables.GITPY_PATH_ENV_VAR_NAME
        )

    class CLITool:
        """
        All help messages for the "gitpy" command of the GitPy CLI Tool.
        """

        @staticmethod
        def main_help_msg():
            """
            The help message of the "gitpy" command ("gitpy --help")

            Returns:
                message (str): The main help message of the GitPy CLI Tool.
            """

            return """\n{SB4}{bold}Gitpy{W}, a Python CLI utility to search and download a Git repository.

            \rFor bugs and errors, please open an issue at <%s> or send a report to
            \r<%s>.

            \rusage: gitpy <{underscore}command{W}>... [{underscore}options{W}...]

            \r   Options:    Metavar:   Description:
            \r   {SB4}{bold}========{W}    {SB4}{bold}========{W}   {SB4}{bold}============{W}
            \r   config      {LG}{bold}[+]{W}        Manipulate the GitPy's config.
            \r   info        {LG}{bold}[+]{W}        Show some information about GitPy and exit.
            \r   install     {LG}{bold}[+]{W}        Install GitPy with all dependencies on your system.
            \r   repo        {LG}{bold}[+]{W}        Search, manage, and subscribe to a Git repository.
            \r   uninstall   {LG}{bold}[+]{W}        Uninstall GitPy from your system.
            \r   update      {LG}{bold}[+]{W}        Update your GitPy instance to the latest version.
            \r   version     {LG}{bold}[+]{W}        Show program's version and exit.

            \r   Options:               Description:
            \r   {SB4}{bold}========{W}               {SB4}{bold}============{W}
            \r   --help                 Show this help message and exit or show more help for a command and exit.

            \rIf you want to know if a new version of GitPy is available, run: {G}gitpy update check{W}

            \rThe commands with the {LG}{bold}[+]{W} metavar mean that it may require additional command(s)/option(s).
            \rIf you want more details about a command, run: {G}gitpy <command> --help{W}""" % (
                variables.REPO_ISSUES_URL,
                variables.AUTHOR_EMAIL,
            )

        class Commands:
            """
            All help messages for the commands (positional arguments) of the gitpy CLI.
            """

            class Cache:
                """
                All help messages for the "cache" command of the GitPy CLI Tool.
                """

                @staticmethod
                def cache_arg():
                    """
                    The help message of the "cache" command of the GitPy CLI Tool.
                    It also have 2 subcommands:
                        - show
                        - flush

                    Return:
                        message (str): The help message of the "cache" command.
                    """

                    return """\nManage the cache of GitPy.

                    \rusage: gitpy cache <{underscore}command{W}>... [{underscore}options{W}...]

                    \r   Commands:   Metavar:   Description:
                    \r   {SB4}{bold}========={W}   {SB4}{bold}========{W}   {SB4}{bold}============{W}
                    \r   show        {LG}{bold}[+]{W}        Show the cache of GitPy.
                    \r   flush       {LG}{bold}[+]{W}        Flush the cache of GitPy.

                    \r   Option:                Description:
                    \r   {SB4}{bold}======={W}                {SB4}{bold}============{W}
                    \r   --help                 Show this help message and exit.

                    \rIf you want more details about a command, run: {G}gitpy cache <command> --help {W}"""

                @staticmethod
                def show_arg():
                    """
                    The help message of the "show" command of the "cache" command of the gitpy main command.

                    Return:
                        message (str): The help message of the "show' command.
                    """

                    return """\nShow cache of GitPy.

                    \rusage: gitpy cache show [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy cache show --help <option>{W}"""

                @staticmethod
                def flush_arg():
                    """
                    The help message of the "flush" command of the "cache" command of the gitpy main command.

                    Return:
                        message (str): The help message of the "flush' command.
                    """

                    return """\nFlush the cache of GitPy.

                    \rusage: gitpy cache flush [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy cache flush --help <option>{W}"""

            class Config:
                """
                All help messages for the "config" command of the GitPy CLI Tool.
                """

                @staticmethod
                def config_arg():
                    """
                    The help message of the "config" command of the GitPy CLI Tool.
                    It also have 2 subcommands:
                        - show
                        - reset

                    Return:
                        message (str): The help message of the "config" command.
                    """

                    return """\nManipulate the GitPy's config.

                    \rusage: gitpy config <{underscore}command{W}>... [{underscore}options{W}...]

                    \r   Commands:   Metavar:   Description:
                    \r   {SB4}{bold}========={W}   {SB4}{bold}========{W}   {SB4}{bold}============{W}
                    \r   show        {LG}{bold}[+]{W}        Show the content of the GitPy's config file.
                    \r   reset       {LG}{bold}[+]{W}        Reset the GitPy's config file with the default values.

                    \r   Option:                Description:
                    \r   {SB4}{bold}======={W}                {SB4}{bold}============{W}
                    \r   --help                 Show this help message and exit.

                    \rIf you want more details about a command, run: {G}gitpy config <command> --help {W}

                    \rBy default, the config file is in:
                    \r{C}%s{W}

                    \rIf you installed GitPy, the config file is in:
                    \r{C}%s{W}

                    \r   {$} If it say that the {C}{bold}%s{W} environment variable is not found, then you haven't or incorrectly
                    \r   {*} If the command {G}gitpy{W} exists, please reinstall the project by running this command: {G}gitpy install{W}
                    \r   {*} If not, please reinstall the project by cloning it and run this command in the cloned directory to install it: {G}python3 gitpy.py install{W}""" % (
                        variables.DEFAULT_GITPY_CONFIG_FILE_PATH,
                        HelpMessages.gitpy_config_file_path,
                        variables.GITPY_PATH_ENV_VAR_NAME,
                    )

                @staticmethod
                def show_arg():
                    """
                    The help message of the "show" command of the "config" command of the gitpy main command.

                    Return:
                        message (str): The help message of the "show' command.
                    """

                    return """\nShow the content of the GitPy's config file.

                    \rusage: gitpy config show [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy config show --help <option>{W}"""

                @staticmethod
                def reset_arg():
                    """
                    The help message of the "reset" command of the "config" command of the GitPy CLI Tool.

                    Return:
                        message (str): The help message of the "reset" command of the "config" command of the GitPy CLI Tool.
                    """

                    return """\nReset the GitPy's config file with the default values.

                    \rusage: gitpy config reset [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy config reset --help <option>{W}"""

            @staticmethod
            def info_arg():
                """
                The help message of the "info" command of the GitPy CLI Tool.

                Return:
                    message (str): The help message of the "info" command of the "config" command of the GitPy CLI Tool.
                """

                return """\nShow more information about GitPy.

                \rusage: gitpy info [{underscore}options{W}...]

                \r   Options:   Description:
                \r   {SB4}{bold}========{W}   {SB4}{bold}============{W}
                \r   --help     Show this help message and exit."""

            @staticmethod
            def install_arg():
                """
                The help message of the "install" command of the GitPy CLI Tool.

                Return:
                    message (str): The help message of the "install" command.
                """

                return (
                    """\nInstall GitPy on the system.

                \rusage: gitpy install [{underscore}options{W}...]

                \r   Options:                    Metavar:   Description:
                \r   {SB4}{bold}========{W}                    {SB4}{bold}========{W}   {SB4}{bold}============{W}
                \r       --ab, --absolute-path              {O}Don't check{W} if the path entered with the {G}--path{W} argument finish with "gitpy"
                \r       --help                             Show this help message and exit.
                \r       --nc, --no-confirm                 Bypass any and all "Are you sure?" messages.
                \r       --offline                          Install GitPy with the local file already downloaded
                \r                                          (default: {G}download new files from the GitHub repository{W}).
                \r       --path                  {LG}<PATH>{W}     Choose where the GitPy will be install on the system (default: {G}%s{W}).
                \r       --quiet                            Prevent header from displaying. {O}Warning{W}: bypass any "Are you sure?" 
                \r                                          message(s)! (it makes sense)
                \r       --su, --skip-update                Skip the system update phase.
                \r   -v|vv|vvv                              Verbosity level (default: {G}0{W})

                \rIf you want more details about option, run: {G}gitpy install --help <option>{W}"""
                    % variables.DEFAULT_INSTALL_PATH
                )

            class Repo:
                """
                All help messages for the "repo" command of the GitPy CLI tool.
                """

                @staticmethod
                def repo_arg():
                    """
                    The help message of the "repo" command of the GitPy CLI.
                    It also have 2 subcommands:
                        - check
                        - unsub

                    Return:
                        message (str): The help message of the "repo" command.
                    """

                    return """\nManage your subscripted repositories.

                    \rusage: gitpy repo <{underscore}command{W}>... [{underscore}options{W}...]

                    \r   Options:   Metavar:   Description:
                    \r   {SB4}{bold}========{W}   {SB4}{bold}========{W}   {SB4}{bold}============{W}
                    \r   check      {LG}{bold}[+]{W}        Check if an subscripted repo have a new version available.
                    \r   unsub      {LG}{bold}[+]{W}        Unsubscribe to a subbed repository.

                    \r   Options:              Description:
                    \r   {SB4}{bold}========{W}              {SB4}{bold}============{W}
                    \r   --help                Show this help message and exit.

                    \rIf you want more details about a command, run: {G}gitpy repo <command> --help {W}"""

                @staticmethod
                def check_arg():
                    """
                    The help message of the "check" command of the "repo" command of the GitPy CLI Tool.

                    Return:
                        message (str): The help message of the "check" command.
                    """

                    return """\nCheck if an subscripted repo have a new version available.

                    \rusage: gitpy repo check [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy repo check --help <option>{W}"""

                @staticmethod
                def unsub_arg():
                    """
                    The help message of the "unsub" command of the "repo" command of the GitPy CLI Tool.

                    Return:
                        message (str): The help message of the "unsub" command.
                    """

                    return """\nUnsubscribe to a subscripted repository.

                    \rusage: gitpy repo unsub [{underscore}options{W}...]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})

                    \rIf you want more details about a option, run: {G}gitpy repo unsub --help <option>{W}"""

                @staticmethod
                def search_arg():
                    """
                    The help message of the "search" command of the "repo" command of the GitPy CLI Tool.

                    Return:
                        message (str): The help message of the "search" command.
                    """

                    return """\nSearch for a public online Git repository.

                    \rusage: gitpy repo search [-a <AUTHOR>] [--help] [-h <{github,gitlab}>] [-l <LANGUAGE>] [-n <REPO-NAME>] [-v]

                    \r   Options:           Metavar:      Required:   Description:
                    \r   {SB4}{bold}========{W}           {SB4}{bold}========{W}      {SB4}{bold}========={W}   {SB4}{bold}============{W}
                    \r   -a,  --author      {LG}<AUTHOR>{W}                  Search for a specific author.
                    \r        --help                                  Show this help message and exit.
                    \r   -h,  --host        {LG}<HOST>{W}                    On what you want to search (default: {G}github{W}).
                    \r   -l,  --language    {LG}<LANG>{W}                    Search for a specific language.
                    \r   -n,  --repo-name   {LG}<REPO-NAME>{W}   Yes         What you want to search.
                    \r   -v|vv|vvv                                    Verbosity level (default: {G}0{W})

                    \rIf you want more details about option, run: {G}gitpy repo search --help <option>{W}"""

            @staticmethod
            def uninstall_arg():
                """
                The help message of the "uninstall" command of the GitPy CLI Tool.

                Return:
                    message (str): The help message of the "uninstall" command.
                """

                return """\nUninstall GitPy from your system.

                \rusage: gitpy uninstall [--help] [--remove-deps] [--nc] [--quiet] [-v]

                \r   Options:                  Description:
                \r   {SB4}{bold}========{W}                  {SB4}{bold}============{W}
                \r       --help                Show this help message and exit.
                \r       --nc, --no-confirm    Bypass any and all "Are you sure?" messages.
                \r       --quiet               Prevent header from displaying. {O}Warning{W}: bypass any "Are your sure?"
                \r                             message(s)! (it makes sense)
                \r       --rd, --remove-deps   Remove all dependencies of GitPy when uninstalling GitPy.
                \r   -v|vv|vvv                 Verbosity level (default: {G}0{W})

                \rIf you want more details about option, run: {G}gitpy uninstall --help <option>{W}"""

            class Update:
                """
                All help messages for the "update" command of the GitPy CLI tool.
                """

                @staticmethod
                def update_arg():
                    """
                    The help message of the "update" command of the GitPy CLI.
                    It also have 1 subcommand:
                        - check

                    Return:
                        message (str): The help message of the "update" command.
                    """

                    return """\nUpdate your GitPy instance to the latest version.

                    \rusage: gitpy update <{underscore}command{W}>... [{underscore}options{W}...]

                    \r   Commands:                        Description:
                    \r   {SB4}{bold}========={W}                        {SB4}{bold}============{W}
                    \r   check                      {LG}{bold}[+]{W}   Check if a new version of GitPy is available.

                    \r   Options:                         Description:
                    \r   {SB4}{bold}========{W}                         {SB4}{bold}============{W}
                    \r       --fu, --force-update         Force the update of GitPy even if it is already up to date.
                    \r       --help                       Show this help message and exit.
                    \r       --nc, --no-confirm           Bypass any and all "Are you sure?" messages.
                    \r       --quiet                      Prevent header from displaying. {O}Warning{W}: bypass any "Are your sure?"
                    \r                                    message(s)! (it makes sense)
                    \r   -v|vv|vvv                        Verbosity level (default: {G}0{W})

                    \rIf you want more details about option, run: {G}gitpy update --help <option>{W}"""

                @staticmethod
                def check_arg():
                    """
                    The help message of the "check" command of the "update" command of the GitPy CLI Tool.

                    Return:
                        message (str): The help message of the "check" of the "update" command of the GitPy CLI Tool.
                    """

                    return """\nCheck if a new version of GitPy is available.

                    \rusage: gitpy update check [--help] [-v]

                    \r   Options:     Description:
                    \r   {SB4}{bold}========{W}     {SB4}{bold}============{W}
                    \r       --help   Show this help message and exit.
                    \r   -v|vv|vvv    Verbosity level (default: {G}0{W})
                    
                    \rIf you want more details about a option, run: {G}gitpy update check --help <option>{W}"""

            @staticmethod
            def version_arg():
                """
                The help message of the "version" command of the GitPy CLI Tool.

                Return:
                    message (str): The help message of the "version" command.
                """

                return """\nShow program's version and exit.

                \rusage: gitpy version [--help] [-v]

                \r   Options:          Description:
                \r   {SB4}{bold}========{W}          {SB4}{bold}============{W}
                \r       --help        Show this help message and exit.
                \r   -v|vv|vvv|vvvv    Verbosity level (default: {G}0{W})

                \rIf you want more details about option, run: {G}gitpy version --help <option>{W}"""

        class Options:
            """
            The help message of the options of the GitPy CLI Tool.
            """

            @staticmethod
            def option_no_confirm(command):
                """
                The help message for the --nc/--no-confirm option
                """

                return (
                    """\nBypass all "Are your sure?" style message.

                \rusage: gitpy %s [--nc | --no-confirm]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   install                Install GitPy on your system.
                \r   uninstall              Uninstall GitPy from your system.
                \r   update                 Update your GitPy instance to the latest version."""
                    % command
                )

            @staticmethod
            def option_path(command):
                """
                The help message for the --path option
                """

                return (
                    """\nYou can specify the path where GitPy will be installed.
                \rBy default, GitPy will be installed in %s.

                \rusage: gitpy %s [--path <PATH>]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   install                Install GitPy on your system."""
                    % command
                )

            @staticmethod
            def option_offline(command):
                """
                The help message for the --offline option
                """

                return (
                    """\nInstall GitPy from the local files (do not download anything).
                \rBy default, the installation process will download the latest 
                \rversion of GitPy from the Git repository.

                \rusage: gitpy %s [--offline]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   install                Install GitPy on your system."""
                    % command
                )

            @staticmethod
            def option_skip_update(command):
                """
                The help message for the --su/--skip-update option
                """

                return (
                    """\nDo not run the system update during the installation process.

                \rusage: gitpy %s [--su |--skip-update]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   install                Install GitPy on your system."""
                    % command
                )

            @staticmethod
            def option_quiet(command):
                """
                The help message for the --quiet option
                """

                return (
                    """\nNo output given and bypass all "Are you sure?" style message.

                \rusage: gitpy %s [--quiet]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   install                Install GitPy on your system.
                \r   uninstall              Uninstall GitPy from your system.
                \r   update                 Update your GitPy instance to the latest version."""
                    % command
                )

            @staticmethod
            def option_verbose(command):
                """
                The help message for the -v option
                """

                help_message = """\nGet more information while the script is running.
                \rThe default value of the verbose level is {G}0{W}.

                \rusage: gitpy %s [-v, -vv, ...]

                \r   Compatible Commands:   Description:                                                 Parent command:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}                                                 {SB4}{bold}==============={W}
                \r   install                Install GitPy on your system.
                \r   uninstall              Uninstall GitPy from your system.
                \r   update                 Update your GitPy instance to the latest version.
                \r   version                Show program's version and exit.
                \r   {SB3}{bold}--------------------{W}   {SB3}{bold}------------{W}                                                 {SB3}{bold}---------------{W}
                \r   show                   Show the cache of GitPy.                                     cache
                \r   flush                  Flush the cache of GitPy.                                    cache
                \r   show                   Show the content of the GitPy's config file                  config
                \r   reset                  Reset the GitPy' config file with the default values.        config
                \r   check                  Check if an subscripted repo have a new version available.   repo
                \r   unsub                  Unsubscribe to a subscripted repository.                     repo
                \r   check                  Check if a new version of GitPy is available.                update""" % (
                    command,
                )

                if command == "version":
                    verbose_differences = """\n\n   Verbosity level:       Description:
                    \r   {SB4}{bold}================{W}       {SB4}{bold}============{W}
                    \r   -v                     Only show the version number of GitPy.
                    \r   -vv                    Show the version of GitPy and the Python version.
                    \r   -vvv                   Show the version of GitPy, copyright, the license used,
                    \r                          bug report info, and the Python version.
                    \r   -vvvv                  All from the {G}-vvv{W} with all dependencies version."""

                if command == "install":
                    verbose_differences = """\n\n   Verbosity level:       Description:
                    \r   {SB4}{bold}================{W}       {SB4}{bold}============{W}
                    \r   -v                     Show the commands executed on the system.
                    \r   -vv                    Show the commands executed on the system and the output of them.
                    \r   -vvv                   All from {G}-vv{W} with 
                    \r   -vvvv                  All from the {G}-vvv{W} with all dependencies version."""

                help_message += verbose_differences

                return help_message

            @staticmethod
            def option_force_update(command):
                """
                The help message for the --fu/--force-update option
                """

                return (
                    """\nUpdate GitPy even if the GitPy's instance version on the machine is
                \ralready the latest. Useful if some files are missing or corrupted.

                \rusage: gitpy %s [--fu | --force-update]

                \r   Compatible Commands:   Description:
                \r   {SB4}{bold}===================={W}   {SB4}{bold}============{W}
                \r   update                 Update your GitPy instance to the latest version."""
                    % command
                )

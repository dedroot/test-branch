#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ change_gitpy_settings_value.py [ Created: 2023-07-21 | 16:18 ]  #
#                                            [ Updated: 2023-07-21 | 16:18 ]  #
# ---[Description & File Language]------------------------------------------- #
#  A small function to change value of the settings.py file                   #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is used to change value of the settings.py file
"""

import fileinput
import os

from gitpy.configs.variables import GITPY_PATH_ENV_VAR_NAME


def change_gitpy_settings_value(variable: str, value: str) -> None:
    """
    A small function to change value of the settings.py file
    """

    # Get install path for find the settings.py file
    try:
        gitpy_install_path = os.environ[GITPY_PATH_ENV_VAR_NAME]
    except KeyError:
        gitpy_install_path = "NO_GITPY_PATH_ENV_VAR_FOUND"

    # Check if the settings.py file exists with the GitPy's install path environment variable
    if os.path.exists("%s/gitpy/src/configs/settings.py" % gitpy_install_path):
        settings_file_path = "%s/gitpy/src/configs/settings.py" % gitpy_install_path
    else:
        # If the settings.py file doesn't exist with the GitPy's install path environment variable,
        # we can know that the user doesn't installed GitPy yet.
        settings_file_path = "./gitpy/src/configs/settings.py"

    # Use fileinput to modify the file in place
    for line in fileinput.input(settings_file_path, inplace=True):
        if line.startswith(variable):
            line = '%s = "%s"\n' % (variable, value)
        print(line, end="")

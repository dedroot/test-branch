#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ check_path.py                  [ Created: 2023-02-21 | 11:12 ]  #
#                                            [ Updated: 2023-08-21 | 11:12 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Check if the folder_path finish with folder_name argument.                 #
#  Example: If the user give '/home' in folder_path, it will add the          #
#  folder_name value to the folder_path. So it give '/home/<folder_name>/'    #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch distros, for the moment)  #
# --------------------------------------------------------------------------- #


"""
This module contains the function for check if the
folder_path finish with folder_name argument or not.
"""


from pathvalidate import sanitize_filepath

from gitpy.utils.colors import Color
from gitpy.utils.exit_tool import exit_tool


def check_folder_path(folder_path, folder_name="", mode="normal"):
    """
    Check if the folder_path finish with the folder_name argument value.

    Arguments:
        folder_path (str): The folder path to check.
        folder_name (str): The folder name to add to the folder_path if it's not already present.
        mode (str): normal - Make basic checks to verify if the folder_path is correct (syntaxly), finish_with - Check if the folder_path finish with the folder_name argument value.

    Returns:
        folder_path (str): The folder path with folder_name at the end
    """

    if mode == "normal":
        if not folder_path.startswith("/"):
            exit_tool(
                status=1,
                message="   {!} You must give the absolute path!",
            )
        if "//" in folder_path:
            exit_tool(
                status=1,
                message=Color.pl(
                    "   {!} The path must not contain double slash (//)!",
                ),
            )
        folder_path = sanitize_filepath(folder_path, platform="Linux")

    elif mode == "finish_with":
        if not folder_path.startswith("/"):
            exit_tool(
                status=1,
                message=Color.pl("   {!} You must give the absolute path!"),
            )
        if "//" in folder_path:
            exit_tool(
                status=1,
                message=Color.pl(
                    "   {!} The path must not contain double slash (//)!",
                ),
            )
        folder_path = sanitize_filepath(folder_path, platform="Linux")
        if folder_path.endswith("%s/" % folder_name):
            # remove the "/" at the end of the folder_path
            folder_path = folder_path[:-1]
        elif folder_path.endswith(folder_name):
            pass
        elif not folder_path.endswith(folder_name):
            if folder_path.endswith("/"):
                folder_path += folder_name
            else:
                folder_path += "/%s" % folder_name

    return folder_path

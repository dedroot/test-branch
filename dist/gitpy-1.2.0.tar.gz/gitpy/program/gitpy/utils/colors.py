#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ colors.py                       [Created: 2023-02-21 | 08:37 ]  #
#                                             [Updated: 2023-07-01 | 18:02 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Color class to prompt texts with colors                                    #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module print a text with a color, to print stack
traces with colors, etc.
"""


import os
import sys
from traceback import format_exc

from colored import fore_rgb


class Color:
    """
    Class to print a text with a color, to print stack,etc.
    """

    last_sameline_length = 0

    # Basic colors
    colors = {
        "W": "\033[0m",  # white (like 'reset')
        "D": "\033[2m",  # dims current color
        "R": "\033[31m",  # red
        "O": "\033[33m",  # orange
        "G": "\033[32m",  # green
        "GR": "\033[37m",  # gray
        "B": "\033[34m",  # blue
        "P": "\033[35m",  # purple
        "C": "\033[36m",  # cyan
        # Light colors
        "LG": "\033[90m",  # light gray
        "LR": "\033[91m",  # light red
        "LL": "\033[92m",  # light green
        "LY": "\033[93m",  # light yellow
        "LB": "\033[94m",  # light blue
        "LP": "\033[95m",  # light purple
        # Dark colors
        "darkblack": "\033[030m",
        "darkR": "\033[031m",
        "darkgreen": "\033[032m",
        "darkyellow": "\033[033m",
        "darkB": "\033[034m",
        "darkmagenta": "\033[035m",
        "darkcyan": "\033[036m",
        "darkwhite": "\033[037m",
        # Text formating
        "bold": "\033[1m",
        "dark": "\033[2m",
        "italic": "\033[3m",
        "underscore": "\033[4m",
        # Colored's PIP package color
        # The 'S' is for 'Special'
        # "SG1": fg("#00FF80"),  # Green n°1
        # "SG2": fg("#00FF37"),  # Green n°2
        # "SY1": fg("#FFEB3B"),  # Yellow n°1
        # "SB1": fg("#2190B5"),  # Blue n°1
        # "SB2": fg("#1898CC"),  # Blue n°2
        # "SB3": fg("#00658E"),  # Darker Blue n°3
        # "SB4": fg("#1d9bf0"),  # Twitter's Blue n°4
        # "SGR1": fg("#777777"),  # Grey n°1
        # "SW1": fg("#FFFFFF"),  # White n°1 (real white)
        "SG1": fore_rgb(r=0, g=255, b=128),  # Green n°1
        "SG2": fore_rgb(r=0, g=255, b=55),  # Green n°2
        "SY1": fore_rgb(r=255, g=235, b=59),  # Yellow n°1
        "SB1": fore_rgb(r=33, g=144, b=181),  # Blue n°1
        "SB2": fore_rgb(r=24, g=152, b=204),  # Blue n°2
        "SB3": fore_rgb(r=0, g=101, b=142),  # Darker Blue n°3
        "SB4": fore_rgb(r=29, g=155, b=240),  # Twitter's Blue n°4
        "SGR1": fore_rgb(r=119, g=119, b=119),  # Grey n°1
        "SW1": fore_rgb(r=255, g=255, b=255),  # White n°1 (real white)
        # "SW0": style("reset"),  # Reset
    }

    # Helper string replacements
    replacements = {
        # Process
        "{-}": "{W}{D}[{W}{G}-{W}{D}]{W}",  # Process in execution
        "{+}": "{W}{D}[{W}{G}+{W}{D}]{W}",  # Finished process with no error
        "{+R}": "{W}{D}[{W}{R}+{W}{D}]{W}",  # Finished process with error
        # Others
        "{!}": "{W}{D}[{W}{R}!{W}{D}]{W}",  # Error
        "{$}": "{W}{D}[{W}{O}!{W}{D}]{W}",  # Warning
        "{>}": "{W}{D}[{W}{C}>{W}{D}]{W}",  # Input (string)
        "{?}": "{W}{D}[{W}{C}?{W}{D}]{W}",  # Question
        "{*}": "{W}{D}[{W}{G}*{W}{D}]{W}",  # Information(s)
        # For verbose
        "{&}": "{W}{D}[{W}{C}*{W}{D}]{W}",
        "{&-}": "{W}{D}[{W}{C}-{W}{D}]{W}",
        "{&+}": "{W}{D}[{W}{C}+{W}{D}]{W}",
        "{#}": "{W}{D}[{W}{P}*{W}{D}]{W}",
        "{§}": "{W}{D}[{W}{SY1}*{W}{D}]{W}",
        "{§-}": "{W}{D}[{W}{SY1}-{W}{D}]{W}",
        "{§+}": "{W}{D}[{W}{SY1}+{W}{D}]{W}",
        "{°}": "{W}{D}[{W}{SW1}*{W}{D}]{W}",
    }

    @staticmethod
    def p(text):
        """
        Prints text using colored format on same line.
        """

        sys.stdout.write(Color.s(text))
        sys.stdout.flush()
        if "\r" in text:
            text = text[text.rfind("\r") + 1 :]
            Color.last_sameline_length = len(text)
        else:
            Color.last_sameline_length += len(text)

    @staticmethod
    def pl(text):
        """
        Prints text using colored format with trailing new line.
        """

        Color.p("%s\n" % text)
        Color.last_sameline_length = 0

    @staticmethod
    def pe(text):
        """
        Prints text using colored format with leading and trailing new line to STDERR.

        Arguments:
            text (str) - Text to print
        """

        sys.stderr.write(Color.s("%s\n" % text))
        Color.last_sameline_length = 0

    @staticmethod
    def s(text):
        """
        Returns colored string
        """

        output = text
        for key, value in Color.replacements.items():
            output = output.replace(key, value)
        for key, value in Color.colors.items():
            output = output.replace("{%s}" % key, value)
        return output

    @staticmethod
    def clear_line():
        """
        Clears the current line.
        """

        spaces = " " * Color.last_sameline_length
        sys.stdout.write("\r%s\r" % spaces)
        sys.stdout.flush()
        Color.last_sameline_length = 0

    @staticmethod
    def clear_entire_line():
        """
        Clears the entire line.
        """

        (rows, columns) = os.popen("stty size", "r").read().split()
        Color.p("\r" + (" " * int(columns)) + "\r")

    @staticmethod
    def pexception(exception):
        """
        Prints an exception. Includes stack trace if necessary.

        Arguments:
            exception (Exception) - Exception to print
        """

        from gitpy.parse import Configuration

        Color.pl("\n   {!} {R}Error: %s" % str(exception))

        # Don't dump trace for the "no targets found" case.
        if "No targets found" in str(exception):
            return

        if Configuration.verbose > 0:
            Color.pl("   {!} Full stack trace below")
            Color.p("   {!}    ")
            err = format_exc().strip()
            err = err.replace("\n", "\n   {!} {C}   ")
            err = err.replace("   File", "{W}File")
            err = err.replace("   Exception: ", "{R}Exception:{W}")
            Color.pl(err)


# For testing replacements
if __name__ == "__main__":
    Color.pl("{-} Testing...")
    Color.p("{+} Test complete")
    Color.pe("{-} Updating...")
    Color.pl("{!} No update package found")

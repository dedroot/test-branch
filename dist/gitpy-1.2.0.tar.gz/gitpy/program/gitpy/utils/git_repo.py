#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ git_repo.py                    [ Created: 2023-02-21 | 11:12 ]  #
#                                            [ Updated: 2023-07-21 | 16:38 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Some function to work with the GitPy's Git repository                      #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is used to work with the GitPy's Git repository.
"""


import re

import requests
import semantic_version
from git import Repo

import gitpy.configs.variables as variables
from gitpy.utils.change_gitpy_settings_value import change_gitpy_settings_value
from gitpy.utils.colors import Color
from gitpy.utils.internet_check import internet_check
from gitpy.utils.process import Process


class GitRepo:
    """
    Class to work with the GitPy' Git repository
    """

    summary = {
        "error_code": int,  # 0 - No error, 1 - Error, 2 - keyboard interrupt, 3 - No internet connection
        "if_new_version": bool,  # True - A new version is available, False - No new version is available
        "internet_status": bool,  # True - Internet connection is available, False - Internet connection is not available
        "is_reachable_function_return": {
            "error_code": int,  # 0 - No error, 1 - Error, 2 - keyboard interrupt, 3 - No internet connection
            "reachable": bool,  # True - Reachable, False - Not reachable
            "web_status_code": int,  # 0 - Unknown, 200 - OK, 404 - Not Found
        },
        "branch": {
            "master": {
                "web_status_code": int,  # 0 - Unknown, 200 - OK, 404 - Not Found
                "metadata": {
                    "version": str,  # The version of the GitPy's Git repository
                },
            },
        },
    }

    @staticmethod
    def clone(repo_url, destination_folder=".") -> None:
        """Clone the a repo to a specific folder

        Arguments:
            repo_url (str): The URL of the repository.
            destination_folder (str): The absolute path where the repository will be cloned
        """

        Process.call(
            "git clone %s %s" % (repo_url, destination_folder),
            shell=True,
            new_line_before=True,
        )

    @staticmethod
    def is_reachable(repo_url, timeout=3):
        """
        Checks if a Git repository is reachable.
        A repository is considered reachable if it is not in private mode.

        Arguments:
            repo_url (str): The URL of the repository to check.

        Returns:
            tuple: (error_code, status_code, reachable)
                error_code (int): 0 - No error, 1 - Error
                reachable (bool): True - Reachable, False - Not reachable
                web_status_code (int): 0 - Unknown, 200 - OK, 404 - Not Found
        """

        rqst = requests.get(url=repo_url, timeout=timeout)
        if rqst.status_code == 404:
            return (1, False, 404)
        if rqst.status_code == 200:
            return (0, True, 200)

        # else
        return (1, False, rqst.status_code)

    @staticmethod
    def compare_version(
        repo_url,
        settings_url_from_master,
        gitpy_current_version,
    ):
        """
        Compare version between the GitPy instance on the system and the Git repository with the `metadata.yml` file.

        Arguments:
            repo_url (str): The URL of the GitPy' Git repository
            settings_url_from_master (str): The URL of the `settings.py` file from the master branch
            gitpy_current_version (str): The current version of GitPy.

        Returns:
            summary (dict): Summary of the function.
        """

        internet_status = internet_check()
        GitRepo.summary["internet_status"] = internet_status

        if internet_status is True:
            # Check if the repository is reachable
            error_code, reachable, web_status_code = GitRepo.is_reachable(repo_url)
            GitRepo.summary["is_reachable_function_return"]["error_code"] = error_code
            GitRepo.summary["is_reachable_function_return"]["reachable"] = reachable
            GitRepo.summary["is_reachable_function_return"]["web_status_code"] = web_status_code

            if variables.OPTION_VERBOSE > 0:
                Color.pl("   {°} Reachable function return:")
                if error_code == 0:
                    Color.pl("    {SW1}├──{W} error_code      : {G}%s{W}" % error_code)
                else:
                    Color.pl("    {SW1}├──{W} error_code      : {R}%s{W}" % error_code)

                if reachable is True:
                    Color.pl("    {SW1}├──{W} reachable       : {G}%s{W}" % reachable)
                else:
                    Color.pl("    {SW1}├──{W} reachable       : {R}%s{W}" % reachable)

                if web_status_code == 200:
                    Color.pl("    {SW1}└──{W} web_status_code : {G}%s{W}" % web_status_code)
                else:
                    Color.pl("    {SW1}└──{W} web_status_code : {R}%s{W}" % web_status_code)

            if reachable is True:
                # Master branch --------------------------------------------------
                rqst = requests.get(settings_url_from_master, timeout=3)
                fetch_sc = rqst.status_code

                if fetch_sc == 200:
                    data = rqst.text
                    match = re.search(r'^GITPY_ONLINE_VERSION\s*=\s*"(.*)"', data, re.MULTILINE)
                    online_version = match.group(1)

                    online_version = semantic_version.Version(online_version)
                    local_version = semantic_version.Version(gitpy_current_version)

                    if online_version > local_version:
                        Color.pl(
                            """\n   {+} A new version of GitPy is available!
                               \r    {G}├──{W} Local version   : {G}%s{W}
                               \r    {G}├──{W} Online version  : {G}%s{W}
                               \r   {*} You can update your GitPy instance with the {G}update{W} command ({G}gitpy update{W})."""
                            % (local_version, online_version),
                        )
                    else:
                        Color.pl(
                            """\n   {+} Your GitPy instance is up to date!
                               \r    {G}├──{W} Local version   : {G}%s{W}
                               \r    {G}└──{W} Online version  : {G}%s{W}"""
                            % (local_version, online_version),
                        )
                    GitRepo.summary["branch"]["master"]["web_status_code"] = fetch_sc
                    GitRepo.summary["branch"]["master"]["metadata"]["version"] = online_version
                    GitRepo.summary["error_code"] = 0
                    GitRepo.summary["if_new_version"] = True

                    # Write the new version in the settings file
                    online_version = str(online_version)
                    change_gitpy_settings_value(variable="GITPY_ONLINE_VERSION", value=online_version)
                else:
                    GitRepo.summary["branch"]["master"]["web_status_code"] = fetch_sc
                    GitRepo.summary["branch"]["master"]["metadata"]["version"] = None
            else:
                GitRepo.summary["error_code"] = 1
                GitRepo.summary["if_new_version"] = False

                GitRepo.summary["branch"]["master"]["web_status_code"] = None
                GitRepo.summary["branch"]["master"]["metadata"]["version"] = None
        else:
            GitRepo.summary["error_code"] = 3
            GitRepo.summary["reachable"] = None
            GitRepo.summary["if_new_version"] = None

            GitRepo.summary["branch"]["master"]["web_status_code"] = None
            GitRepo.summary["branch"]["master"]["metadata"]["version"] = None

        return GitRepo.summary

    # Exit codes:
    # 0, None: Success
    # 1: Error
    # 2: Command line syntax errors
    # 120: Error during process cleanup.
    # 255: Exit code out of range.

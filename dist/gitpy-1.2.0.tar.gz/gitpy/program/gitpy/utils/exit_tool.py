#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ exit_tool.py                   [ Created: 2023-03-28 | 08:54 ]  #
#                                            [ Updated: 2023-10-10 | 16:33 ]  #
# ---[Description & File Language]------------------------------------------- #
#  A function to exit GitPy with a specific exit status code and a message    #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This file contains a function to exit the tool with a
message if verbose was applied
"""


import sys

import gitpy.configs.variables as variables
from gitpy.utils.colors import Color
from gitpy.utils.remove_python_cache import remove_python_cache


def print_message(message, file=None):
    """
    Print a message in exit.
    """

    if message:
        if file is None:
            file = sys.stderr
        file.write(message)


def exit_tool(message=None, status=0, remove_cache=False):
    """
    Exit and remove Python3 cache with a message if verbose was applied

    Arguments:
        code (int): Exit code
        cwd (str): Current working directory
    """

    if message:
        print_message(message, sys.stderr)

    if remove_cache is True:
        remove_python_cache()
    if variables.OPTION_VERBOSE == 3:
        if status == 0:
            Color.pl("  {§} Exiting with the exit code: {G}0{W}")
            Color.pl("   {SY1}└──{W} Python: {SY1}sys.exit(0){W}")
        else:
            Color.pl("  {§} Exiting with the exit code: {R}1{W}")
            Color.pl("   {SY1}└──{W} Python: {SY1}sys.exit(1){W}")
    sys.exit(status)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ clear.py                        [Created: 2023-02-21 |  8:35 ]  #
#                                             [Updated: 2023-05-09 | 23:53 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The terminal prompt clear function                                         #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module is used to clear the terminal prompt.
"""


import os
import subprocess


def clear():
    """
    Clear the terminal prompt.
    """

    # For Windows OS (probably for a future version compatible with Windows)
    if os.name == "nt":
        command = "cls"

    # For Linux OS (mainly for the moment)
    else:
        command = "clear"

    # Execute the command via the subprocess module
    subprocess.call(command, shell=True)

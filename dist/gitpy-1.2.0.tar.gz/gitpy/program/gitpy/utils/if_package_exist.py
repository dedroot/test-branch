#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ if_package_exists.py           [ Created: 2023-02-28 |  8:46 ]  #
#                                            [ Updated: 2023-06-20 | 15:30 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Check if a package are installed on the machine                            #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module contains all help messages for GitPy.
"""


import subprocess

from gitpy.utils.based_distro import detect_based_distro


def package_exists(package):
    """
    Check if package are install on the machine
    """

    if detect_based_distro() == "Debian":
        result = subprocess.run("dpkg -s %s" % package, shell=True, stdout=subprocess.PIPE)
    elif detect_based_distro() == "Arch":
        result = subprocess.run("pacman -Q %s" % package, shell=True, stdout=subprocess.PIPE)
    return result.stdout != b""

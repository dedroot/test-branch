#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ information.py                 [ Created: 2023-02-28 |  9:21 ]  #
#                                            [ Updated: 2023-08-26 | 17:55 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The information page about GitPy                                           #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module contain the information message of GitPy.
"""


import importlib.metadata as metadata
import sys

import gitpy.configs.variables as variables


class Information:
    """
    The main class of the Information page of GitPy that
    will be called when the user runs 'gitpy info'.
    """

    def main_message() -> str:
        """
        The information message about GitPy.

        Returns:
            message (string): The information message about GitPy.
        """

        gitpy_local_version = variables.GITPY_LOCAL_VERSION
        repo_url = variables.REPO_URL
        repo_clone_url = variables.REPO_CLONE_URL
        repo_changelog_url = variables.REPO_CHANGELOG_URL
        repo_issues_url = variables.REPO_ISSUES_URL
        author_discord = variables.AUTHOR_DISCORD
        author_email = variables.AUTHOR_EMAIL
        author_github = variables.AUTHOR_GITHUB
        author_twitter = variables.AUTHOR_TWITTER
        python_version = sys.version

        # Sorted with the same order as the requirements.txt or pyproject.toml file
        dependencies_version = []
        for dependency in variables.PIP_DEPENDENCIES:
            try:
                version = metadata.version(dependency)
                dependencies_version.append(f"{dependency} ({version})")
            except metadata.PackageNotFoundError:
                dependencies_version.append(f"{dependency} (not found)")

        # print(dependencies_version)
        # for package_info in dependencies_version:
        #     print(package_info)

        information_message = """"
        \r   Information about GitPy:
        \r   {SB4}{bold}========================{W}

        \r      Description
        \r      {SB3}{bold}-----------{W}
        \r      GitPy is a program that can be use to search and download a GitHub repository using the GitHub API REST.
        \r      It can also notify when a subscribed repository has been updated. You can subscribe to a repository when
        \r      you download it via the GitPy's interactive shell.

        \r      Program                  Local Version
        \r      {SB3}{bold}-------{W}                  {SB3}{bold}-------------{W}
        \r      gitpy                    %s
        \r      python                   %s""" % (
            gitpy_local_version,
            python_version,
        )

        # return """

        # \r      Dependencies             Local Version
        # \r      {SB3}{bold}------------{W}             {SB3}{bold}-------------{W}
        # \r      colored                  %s
        # \r      crontab                  %s
        # \r      cryptography             %s
        # \r      packaging                %s
        # \r      pathvalidate             %s
        # \r      pyyaml                   %s
        # \r      requests                 %s
        # \r      rich                     %s
        # \r      semantic_version         %s
        # \r      shtab                    %s
        # \r      urllib3                  %s

        # \r      Copyright & Licensing    Description
        # \r      {SB3}{bold}---------------------{W}    {SB3}{bold}----------- {W}
        # \r      Copyright                Copyright (C) 2023 Thomas Pellissier.
        # \r      License                  This program is under GNU General Public License v3.0 (GPL 3.0).
        # \r                               This is free software: you are free to change and redistribute it.
        # \r                               There is NO WARRANTY, to the extent permitted by law.

        # \r      Other information        Description
        # \r      {SB3}{bold}-----------------{W}        {SB3}{bold}-----------{W}
        # \r      GitHub page URL          <%s>
        # \r      Clone URL                <%s>
        # \r      Changelogs               <%s>
        # \r      Issues pages             <%s>

        # \r   Information about author:
        # \r   {SB4}{bold}========================={W}

        # \r      Main information         Description
        # \r      {SB3}{bold}----------------{W}         {SB3}{bold}-----------{W}
        # \r      Fullname                 Thomas Pellissier
        # \r      Username                 dedroot
        # \r      Email                    <%s> ({bold}only for professional{W} or for {G}report bugs of GitPy{W})

        # \r      Other information        Description
        # \r      {SB3}{bold}-----------------{W}        {SB3}{bold}-----------{W}
        # \r      GitHub profile           <%s>
        # \r      Twitter profile          <%s>
        # \r      Discord username         %s

        # \r   Contributors:
        # \r   {SB4}{bold}============={W}

        # \r      Username                 GitHub profile
        # \r      {SB3}{bold}--------{W}                 {SB3}{bold}-----------{W}
        # \r      Bashy                    <https://github.com/jonas52>""" % (
        #     dependencies_version[0],
        #     dependencies_version[1],
        #     dependencies_version[2],
        #     dependencies_version[3],
        #     dependencies_version[4],
        #     dependencies_version[5],
        #     dependencies_version[6],
        #     dependencies_version[7],
        #     dependencies_version[8],
        #     dependencies_version[9],
        #     dependencies_version[10],
        #     repo_url,
        #     repo_clone_url,
        #     repo_changelog_url,
        #     repo_issues_url,
        #     author_email,
        #     author_github,
        #     author_twitter,
        #     author_discord,
        # )

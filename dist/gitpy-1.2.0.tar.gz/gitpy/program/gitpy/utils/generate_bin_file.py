#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ generate_bin_file.py            [Created: 2023-02-21 | 11:25 ]  #
#                                             [Updated: 2023-10-02 | 23:04 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Create the content of the executable file that will be placed in           #
#  /usr/bin/. After, the command 'gitpy' will be executed anywhere in the     #
#  terminal.                                                                  #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module create the content of the executable file
that will be placed in /usr/bin/.
"""

import datetime

from gitpy.configs.variables import DEFAULT_INSTALL_PATH, GITPY_LOCAL_VERSION


def create_bin_file(path=None):
    """
    Create the content of the executable file that will be placed in /usr/bin/.

    Arguments:
        path (string): The path where the GitPy will be installed.

    Returns:
        exec_file (string): The content of the executable file that will be placed in /usr/bin/.
    """

    if path == None:
        path = DEFAULT_INSTALL_PATH

    date = datetime.datetime.now().strftime("%Y-%m-%d | %H:%M")

    exec_file = """#!/bin/bash
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ gitpy                          [ Created: %s ]  #
# ---[Description & File Language]------------------------------------------- #
#  The bin file for calling GitPy anywhere in the terminal. Because it gonna  #
#  be placed in "/usr/bin".                                                   #
#  Language ~ Bash                                                            #
#  Version ~ %s                                                            #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #

# Go to the directory where GitPy is installed
cd "%s" && .venv/bin/python gitpy.py $@

# Run GitPy using the virtual environment

""" % (
        date,
        GITPY_LOCAL_VERSION,
        path,
    )

    return exec_file

from gitpy.parse import Configuration
from gitpy.utils.colors import Color
from gitpy.utils.exit_tool import exit_tool
from gitpy.utils.git_repo import GitRepo as GR


def check_update():
    (
        error_code,
        status_code,
        reachable,
        new_version,
        gitpy_online_ver,
        found_mtd_develop,
        found_mtd_master,
        internet_status,
    ) = GR.compare_version(
        verbose=Configuration.verbose,
        repo_url=Configuration.repo_url,
        repo_metadata_url_from_master=Configuration.repo_metadata_url_from_master,
        repo_metadata_url_from_develop=Configuration.repo_metadata_url_from_develop,
        CURRENT_VERSION=Configuration.version,
    )

    if internet_status is True:
        if reachable is True:
            if new_version == True:
                Color.pl(
                    "\n  {+} A new version of GitPy is available: {G}%s{W}"
                    % gitpy_online_ver
                )
                Color.pl(
                    "  {*} You can update your GitPy instance with the {G}update{W} command."
                )
                return_line = False
            else:
                if Configuration.verbose > 0:
                    if gitpy_online_ver == "?":
                        Color.pl(
                            "  {°} Online version of GitPy is unknown. Because the {C}metadata.yml{W} file is unreachable."
                        )
                    else:
                        Color.pl(
                            "  {°} No new version of GitPy is available. You are using the latest version."
                        )
                        Color.pl(
                            "  {°} The local version is {G}%s{W} and the online version is {G}%s{W}."
                            % (Configuration.version, gitpy_online_ver)
                        )
        else:
            return_line = True
            exit_tool(
                status=1,
                message=Color.pl("\n  {!} The {C}gitpy{W} repository is unreachable."),
            )
    else:
        return_line = True
        exit_tool(
            status=1,
            message=Color.pl(
                "\n  {!} Not Internet connection available. Please check your internet connection and try again.",
            ),
        )

    if found_mtd_master is False:
        if return_line is True:
            Color.pl(
                "  {$} The {C}metadata.yml{W} file is not found in the {G}master{W} branch."
            )
        else:
            Color.pl(
                "\n {$} The {C}metadata.yml{W} file is not found in the {G}master{W} branch."
            )
        if found_mtd_develop is False:
            pass

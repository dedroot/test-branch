#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ based_distro.py                [ Created: 2023-02-07 |  8:38 ]  #
#                                            [ Updated: 2023-07-12 | 15:05 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The function for check if the user's machine ran on a Debian distro        #
#  based or an Arch based.                                                    #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module contains the function for check if the user's
machine ran on a Debian distro based or an Arch based.
"""


def detect_based_distro():
    """
    Detects if the Linux distro installed on the machine is based on Arch or Debian and returns the based distro name.

    Returns:
        string: The based distro name (Debian, Arch or None (if the distro is not supported))
    """

    # Check the ID_LIKE variable in the /etc/os-release file
    try:
        with open("/etc/os-release", "r") as os_release:
            for line in os_release.readlines():
                if line.startswith("ID_LIKE="):
                    if "debian" in line.lower():
                        return "Debian"
                    elif "arch" in line.lower():
                        return "Arch"
                    else:
                        return None
    except FileNotFoundError:
        pass

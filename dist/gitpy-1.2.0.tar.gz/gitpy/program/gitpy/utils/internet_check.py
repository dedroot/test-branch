#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ internet_check.py               [Created: 2023-02-21 |  8:32 ]  #
#                                             [Updated: 2023-06-19 | 23:34 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Check if the user are connected to the Internet or not                     #
#  Language ~ Python3                                                         #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module is used to check if the user are
connected to the Internet or not
"""


import requests


def internet_check(host="https://one.one.one.one", timeout=3):
    """
    Check if the user are connected to the Internet or not.

    Arguments:
        host (str): The host to check the connection (simple GET request). Default: https://one.one.one.one
        timeout (int): The timeout of the request. Default: 3

    Returns:
        tuple: (has_internet, status_code)
            has_internet (bool): True - Connected, False - Not connected
            status_code (int): 0 - Unknown, 200 - OK, 404 - Not Found, 408 - Timeout, 10 - Keyboard interrupt
    """

    try:
        response = requests.get(url=host, timeout=timeout)
        if response.status_code == 200:
            return (True, 200)
    except requests.exceptions.RequestException:
        return (False, response.status_code)

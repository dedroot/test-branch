#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ remove_python_cache.py         [ Created: 2023-03-07 | 09:21 ]  #
#                                            [ Updated: 2023-10-10 | 16:33 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Remove the __pycache__ folder in the GitPy's folder                        #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch, for the moment)          #
# --------------------------------------------------------------------------- #


"""
This module contain a function to remove all __pycache__'s 
folders in the GitPy's folder.
"""


import os
import shutil

import gitpy.configs.variables as variables
from gitpy.utils.colors import Color


def remove_python_cache(line_enter=False):
    """
    Remove all __pycache__ folder in the GitPy's folder

    Arguments:
        line_enter (bool): True - Add a line before the "Removing python cache..." message,
                           False - Don't add a line before the "Removing python cache..." message

    Returns:
        summary (dict): Summary of the function.
    """

    cwd = variables.CWD
    verbose = variables.OPTION_VERBOSE

    summary = {
        "error_code": int,  # 0 - No error, 1 - Error, 2 - keyboard interrupt, 3 - Permission error
        "perm_error": bool,  # True - Permission error, False - No permission error
        "number_folder_deleted": int,  # Number of folder deleted
        "number_folder_not_deleted": int,  # Number of folder not deleted
        "deleted_folders": list,  # List of deleted folders
    }
    count = 0  # Number of __pycache__ folders
    pycache_folders = []  # List of __pycache__ folders
    deleted_folders = []
    number_folder_deleted = 0
    number_folder_not_deleted = 0
    file_perm_error = False
    perm_error = False
    error_code = 0
    folder_number_in_process = 1
    prompt = ""

    # prompt_longer_line_length = []   # See TODO at the end of the function for more information about this variable

    # Find all __pycache__ folders
    for root, dirs, files in os.walk(cwd):
        for d in dirs:
            if d == "__pycache__":
                count += 1
                pycache_folders.append(os.path.join(root, d))

    if count > 0:
        if verbose > 0:
            Color.pl("  {§} Verbose level: %s" % verbose)
            if os.getuid() == 0:
                Color.pl("  {$} Using root privileges.")
            if line_enter is True:
                Color.pl("\n  {§-} Removing python cache...")
            else:
                Color.pl("  {§-} Removing python cache...")

        for folder_path in pycache_folders:
            rel_path = os.path.relpath(folder_path, cwd)
            try:
                if verbose == 1:
                    if count != folder_number_in_process:
                        prompt += "   {SY1}├──{W} Folder: {C}%s{W}" % rel_path
                    else:
                        prompt += "   {SY1}└──{W} Folder: {C}%s{W}" % rel_path
                if verbose >= 2:
                    if count != folder_number_in_process:
                        prompt += '   {SY1}├──{W} Python: {SY1}shutil.rmtree("{C}%s{W}{SY1}"){W}' % folder_path
                    else:
                        prompt += '   {SY1}└──{W} Python: {SY1}shutil.rmtree("{C}%s{W}{SY1}"){W}' % folder_path
                shutil.rmtree(folder_path)
                deleted_folders.append(folder_path)
                number_folder_deleted += 1

            except PermissionError:
                file_perm_error = True
                perm_error = True
                error_code = 3
                number_folder_not_deleted += 1
                prompt += "\t\t{W}{D}[{W}{R}   PERMISSION DENIED   {W}{D}]{W}"

            except KeyboardInterrupt:
                error_code = 2
                break

            finally:
                if file_perm_error is False:
                    prompt += "\t\t{W}{D}[{W}{G}          OK           {W}{D}]{W}"
                if count != folder_number_in_process:
                    prompt += "\n"
                    folder_number_in_process += 1
                else:
                    pass
                file_perm_error = False

        summary["error_code"] = error_code
        summary["perm_error"] = perm_error
        summary["number_folder_deleted"] = number_folder_deleted
        summary["number_folder_not_deleted"] = number_folder_not_deleted
        summary["deleted_folders"] = deleted_folders

    else:
        summary["error_code"] = 0
        summary["perm_error"] = False
        summary["number_folder_deleted"] = 0
        summary["number_folder_not_deleted"] = 0
        summary["deleted_folders"] = []

    #
    #   TODO: Prompt [   PERMISSION DENIED   ] and [          OK           ] aligned, like this:
    #
    #    [-] Removing python cache...
    #     ├── Folder: tests/__pycache__                              [   PERMISSION DENIED   ]
    #     ├── Folder: gitpy/__pycache__                              [          OK           ]
    #     ├── Folder: gitpy/src/__pycache__                          [          OK           ]
    #     └── Folder: gitpy/src/utils/__pycache__                    [   PERMISSION DENIED   ]
    #
    #         I tried to do it but it's not working, I don't know how to do it. If you have an idea, please open an issue on the GitHub's repository.
    #

    # prompt_cleaned = (
    #     prompt.replace("{§}", "")
    #     .replace("{§-}", "")
    #     .replace("{§+}", "")
    #     .replace("{SY1}", "")
    #     .replace("{W}", "")
    #     .replace("{D}", "")
    #     .replace("{C}", "")
    #     .replace("{G}", "")
    #     .replace("{R}", "")
    #     .replace("[   PERMISSION DENIED   ]", "")
    #     .replace("[          OK           ]", "")
    # )

    # # get the most longer line in prompt
    # promptsplit = prompt_cleaned.split("\n")
    # prompt_longer_line = max(promptsplit, key=len)

    # # get the length of the most longer line in prompt
    # prompt_longer_line_length = len(prompt_longer_line)

    # Color.pl("{C}%s" % prompt_longer_line)
    # print(prompt_longer_line_length)
    # print()
    # print(prompt_cleaned)

    if verbose > 0:
        Color.pl(prompt)

        if number_folder_not_deleted > 0:
            Color.pl(
                "  {§} %s folder%s not deleted."
                % (
                    number_folder_not_deleted,
                    "s" if number_folder_not_deleted > 1 else "",
                )
            )

        else:
            Color.pl("  {§+} Done.")

    return summary

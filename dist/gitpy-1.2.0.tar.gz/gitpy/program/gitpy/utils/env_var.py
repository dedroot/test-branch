#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ env_var.py                     [ Created: 2023-02-21 |  9:32 ]  #
#                                            [ Updated: 2023-06-19 | 23:25 ]  #
# ---[Description & File Language]------------------------------------------- #
#  A module to easily make or remove a environment variables                  #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
A module to easily make or remove a environment variables
"""


import os


def set_env_var(var_name: str, var_value: str):
    """
    Create a environment variable
    """
    # # ---------- [ For the /etc/bash.bashrc file ] ---------- #
    # # Set the environment variable in the current process
    # os.environ[var_name] = var_value
    # # Open the /etc/bash.bashrc file
    # with open("/etc/bash.bashrc", "r") as environment:
    #     # Read the file into a list of lines
    #     lines = environment.readlines()
    # # Flag to check if the variable is found
    # found = False
    # # Iterate over the lines
    # for i, line in enumerate(lines):
    #     # Check if the line starts with var_name
    #     if line.startswith("export %s" % var_name):
    #         # Replace the value of the environment variable
    #         lines[i] = "export %s='%s'\n" % (var_name, var_value)
    #         found = True
    # if not found:
    #     lines.append("export %s='%s'\n" % (var_name, var_value))
    # # Open the /etc/environment file for writing
    # with open("/etc/bash.bashrc", "w") as environment:
    #     # Write the modified lines to the file
    #     environment.writelines(lines)

    # ---------- [ For the /etc/environment file ] ---------- #
    # Open the /etc/environment file
    with open("/etc/environment", "r") as environment:
        # Read the file into a list of lines
        lines = environment.readlines()
    # Flag to check if the variable is found
    found = False
    # Iterate over the lines
    for i, line in enumerate(lines):
        # Check if the line starts with var_name
        if line.startswith(var_name):
            # Replace the value of the environment variable
            lines[i] = "%s='%s'\n" % (var_name, var_value)
            found = True
    if not found:
        lines.append("%s='%s'\n" % (var_name, var_value))
    # Open the /etc/environment file for writing
    with open("/etc/environment", "w") as environment:
        # Write the modified lines to the file
        environment.writelines(lines)


def remove_env_var(var_name: str):
    """
    Remove a environment variable
    """
    # # ---------- [ For the /etc/bash.bashrc file ] ---------- #
    # # Open the /etc/bash.bashrc file
    # with open("/etc/bash.bashrc", "r") as environment:
    #     # Read the file into a list of lines
    #     lines = environment.readlines()
    # # Flag to check if the variable is found
    # found = False
    # # Iterate over the lines
    # for i, line in enumerate(lines):
    #     # Check if the line starts with 'export var_name'
    #     if line.startswith("export %s" % var_name):
    #         # Remove the line of the environment variable
    #         lines[i] = ""
    #         found = True
    # if not found:
    #     pass
    # # Open the /etc/environment file for writing
    # with open("/etc/bash.bashrc", "w") as environment:
    #     # Write the modified lines to the file
    #     environment.writelines(lines)

    # ---------- [ For the /etc/environment file ] ---------- #
    # Open the /etc/environment file
    with open("/etc/environment", "r") as environment:
        # Read the file into a list of lines
        lines = environment.readlines()
    # Flag to check if the variable is found
    found = False
    # Iterate over the lines
    for i, line in enumerate(lines):
        # Check if the line starts with 'var_name'
        if line.startswith(var_name):
            # Remove the line of the environment variable
            lines[i] = ""
            found = True
    if not found:
        pass
    # Open the /etc/environment file for writing
    with open("/etc/environment", "w") as environment:
        # Write the modified lines to the file
        environment.writelines(lines)

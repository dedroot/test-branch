#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ parse.py                       [ Created: 2023-03-28 | 08:35 ]  #
#                                            [ Updated: 2023-10-04 | 17:15 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Parse all arguments and options of the CLI tool                            #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module parse all arguments from the "cli_tool.py" file in the core folder.
In other words, this module parse all arguments and options of the CLI tool.
"""


import pprint

import gitpy.configs.variables as variables


class Parse:
    """
    This class is used to parse all arguments from the "cli_tool.py" file in the core folder.
    """

    class ParseCache:
        """
        Parse the "cache" command's commands and arguments.
        The cache command has 2 subcommands:
            - show
            - flush
        """

        @staticmethod
        def parse_cache_args(args):
            """
            Parse the "cache" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if not args.command or args.help:
                message = HM.CLITool.Commands.Cache.cache_arg()
                exit_tool(status=0, message=Color.pl(message))

        @staticmethod
        def parse_show_args(args):
            """
            Parse the "show" command of the "cache" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help:
                if args.verbose:
                    message = HM.CLITool.Commands.Cache.show_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )
                else:
                    message = HM.CLITool.Commands.Cache.show_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )

        @staticmethod
        def parse_flush_args(args):
            """
            Parse the "flush" command of the "cache" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM
            from gitpy.utils.remove_python_cache import remove_python_cache

            if args.help:
                message = HM.CLITool.Commands.Cache.flush_arg()
                exit_tool(status=0, message=Color.pl(message))
            if args.verbose:
                variables.OPTION_VERBOSE = args.verbose

            summary = remove_python_cache()
            # pprint.pprint(summary)

            error_code = summary["error_code"]
            number_folder_deleted = summary["number_folder_deleted"]
            number_folder_not_deleted = summary["number_folder_not_deleted"]

            if number_folder_deleted > 0:
                if error_code == 0:
                    message = "  {+} Cache successfully flushed."
                    exit_tool(status=error_code, message=Color.pl(message))

                else:
                    if variables.OPTION_VERBOSE == 0:
                        message = "  {!} A problem occurred while flushing cache, use -v for more information."
                        exit_tool(status=error_code, message=Color.pl(message))

                    else:
                        message = "  {!} A problem occurred while flushing cache. See above."
                        exit_tool(status=error_code, message=Color.pl(message))

            else:
                if number_folder_not_deleted > 0:
                    if variables.OPTION_VERBOSE == 0:
                        message = "  {!} A problem occurred while flushing cache, use -v for more information."
                        exit_tool(status=error_code, message=Color.pl(message))

                    else:
                        message = "  {!} A problem occurred while flushing cache."
                        exit_tool(status=error_code, message=Color.pl(message))
                else:
                    if variables.OPTION_VERBOSE > 0:
                        message = "  {§} No cache to flush."
                        exit_tool(status=error_code, message=Color.pl(message))

            exit_tool(status=error_code)

    class ParseConfig:
        """
        Parse the "config" command's commands and arguments.
        The config command has 2 subcommands:
            - show
            - reset
        """

        @staticmethod
        def parse_config_args(args):
            """
            Parse the "config" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if not args.command or args.help:
                message = HM.CLITool.Commands.Config.config_arg()
                exit_tool(status=0, message=Color.pl(message))

        @staticmethod
        def parse_show_args(args):
            """
            Parse the "show" command of the "config" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help:
                if args.verbose:
                    message = HM.CLITool.Commands.Config.show_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )
                else:
                    message = HM.CLITool.Commands.Config.show_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )

        @staticmethod
        def parse_reset_args(args):
            """
            Parse the "show" command of the "config" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help:
                if args.verbose:
                    exit_tool(
                        status=0,
                        message=Color.pl(HM.CLITool.Options.option_verbose()),
                    )
                else:
                    exit_tool(
                        status=0,
                        message=Color.pl(HM.CLITool.Commands.Config.reset_arg()),
                    )

    def parse_info_args(self, args):
        """
        Parse the info command.

        Arguments:
            args (object): The arguments to parse.
        """

        from gitpy.utils.colors import Color
        from gitpy.utils.exit_tool import exit_tool
        from gitpy.utils.help_messages import HelpMessages as HM
        from gitpy.utils.information import Information

        if args.help:
            message = HM.CLITool.Commands.info_arg()
            exit_tool(status=0, message=Color.pl(message))
        else:
            information_message = Information.main_message()
            exit_tool(status=0, message=Color.pl(information_message))

    def parse_install_args(self, args):
        """
        Parse the installation command.

        Arguments:
            args (object): The arguments to parse.
        """

        from gitpy.utils.colors import Color
        from gitpy.utils.exit_tool import exit_tool
        from gitpy.utils.help_messages import HelpMessages as HM

        if args.help:
            if args.skip_update:
                message = HM.CLITool.Options.option_skip_update(command="install")
                exit_tool(status=0, message=Color.pl(message))
            elif args.path:
                message = HM.CLITool.Options.option_path(command="install")
                exit_tool(status=0, message=Color.pl(message))
            elif args.offline:
                message = HM.CLITool.Options.option_offline(command="install")
                exit_tool(status=0, message=Color.pl(message))
            elif args.no_confirm:
                message = HM.CLITool.Options.option_no_confirm(command="install")
                exit_tool(status=0, message=Color.pl(message))
            elif args.quiet:
                message = HM.CLITool.Options.option_quiet(command="install")
                exit_tool(status=0, message=Color.pl(message))
            elif args.verbose:
                message = HM.CLITool.Options.option_verbose(command="install")
                exit_tool(status=0, message=Color.pl(message))
            else:
                message = HM.CLITool.Commands.install_arg()
                exit_tool(status=0, message=Color.pl(message))

        if args.verbose:
            variables.OPTION_VERBOSE = args.verbose
        if args.path == "0":
            message = "  {!} You must specify a path where GitPy will be installed."
            exit_tool(
                message=Color.pl(message),
                status=1,
            )
        if args.quiet and args.verbose:
            message = "  {!} The --quiet and -v option are not compatible together."
            exit_tool(
                message=Color.pl(message),
                status=1,
            )

        from gitpy.commands.install import Installer

        Installer(
            args=args,
        )

    class ParseRepo:
        """
        Parse the "repo" command's commands and arguments.
        The repo command has 2 subcommands:
            - check
            - unsub
        """

        @staticmethod
        def parse_repo_args(args):
            """
            Parse the "repo" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if not args.command or args.help:
                message = HM.CLITool.Commands.Repo.repo_arg()
                exit_tool(status=0, message=Color.pl(message))

        @staticmethod
        def parse_check_args(args):
            """
            Parse the "check" command of the "repo" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help or not args.help:
                message = HM.CLITool.Commands.Repo.check_arg()
                exit_tool(status=0, message=Color.pl(message))

        @staticmethod
        def parse_unsub_args(args):
            """
            Parse the "unsub" command of the "repo" command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help or not args.help:
                message = HM.CLITool.Commands.Repo.unsub_arg()
                exit_tool(status=0, message=Color.pl(message))

        @staticmethod
        def parse_search_args(args):
            """
            Parse the search command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help or not args.help:
                message = HM.CLITool.Commands.Repo.search_arg()
                exit_tool(status=0, message=Color.pl(message))

    def parse_uninstall_args(self, args):
        """
        Parse the installation command.

        Arguments:
            args (object): The arguments to parse.
        """

        from gitpy.utils.colors import Color
        from gitpy.utils.exit_tool import exit_tool
        from gitpy.utils.help_messages import HelpMessages as HM

        if args.help:
            message = HM.CLITool.Commands.uninstall_arg()
            exit_tool(status=0, message=Color.pl(message))
        if args.verbose:
            variables.OPTION_VERBOSE = args.verbose
        if args.quiet and args.verbose:
            message = "  {!} The --quiet and -v option are not compatible together."
            exit_tool(status=1, message=Color.pl(message))

    class ParseUpdate:
        """
        Parse the "update" command's commands and arguments.
        The repo command has 1 subcommand:
            - check
        """

        @staticmethod
        def parse_update_args(args):
            """
            Parse the update command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM

            if args.help:
                if args.verbose:
                    message = HM.CLITool.Options.option_verbose(command="update")
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    ),
                else:
                    message = HM.CLITool.Commands.Update.update_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )
            if args.verbose:
                variables.OPTION_VERBOSE = args.verbose

            from gitpy.commands.update import Updater

            Updater(args=args)

        @staticmethod
        def parse_check_args(args):
            """
            Parse the check command of the update command.

            Arguments:
                args (object): The arguments to parse.
            """

            from gitpy.utils.colors import Color
            from gitpy.utils.exit_tool import exit_tool
            from gitpy.utils.help_messages import HelpMessages as HM
            from tests.git_repo import GitRepo as GR

            if args.help:
                if args.verbose:
                    message = HM.CLITool.Options.option_verbose(command="update")
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )
                else:
                    message = HM.CLITool.Commands.Update.check_arg()
                    exit_tool(
                        status=0,
                        message=Color.pl(message),
                    )

            if args.verbose:
                variables.OPTION_VERBOSE = args.verbose

            summary = GR.compare_version(
                repo_url=variables.REPO_URL,
                gitpy_current_version=variables.GITPY_LOCAL_VERSION,
                settings_url_from_master=variables.REPO_SETTINGS_URL_FROM_MASTER,
                verbose=variables.OPTION_VERBOSE,
            )

            pprint.pprint(summary, depth=10, sort_dicts=False)

    def parse_version_args(self, args):
        """
        Parse the version command.

        Arguments:
            args (object): The arguments to parse.
        """

        def print_version() -> str:
            """
            Print the version of GitPy."""

            if variables.OPTION_VERBOSE == 1:
                return variables.VERSION_MESSAGE

            elif variables.OPTION_VERBOSE == 2:
                return variables.VERSION_MESSAGE_VERBOSE2

            elif variables.OPTION_VERBOSE == 3:
                return variables.VERSION_MESSAGE_VERBOSE3

            elif variables.OPTION_VERBOSE >= 4:
                return variables.VERSION_MESSAGE_VERBOSE4

            else:
                return variables.VERSION_MESSAGE_VERBOSE2

        from gitpy.utils.colors import Color
        from gitpy.utils.exit_tool import exit_tool
        from gitpy.utils.help_messages import HelpMessages as HM

        if args.help:
            if args.verbose:
                message = HM.CLITool.Options.option_verbose(command="version")
                exit_tool(status=0, message=Color.pl(message))
            else:
                message = HM.CLITool.Commands.version_arg()
                exit_tool(status=0, message=Color.pl(message))

        if args.verbose:
            variables.OPTION_VERBOSE = args.verbose

        Color.pl(print_version())

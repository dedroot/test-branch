#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ installer.py                   [ Created: 2023-03-07 | 10:27 ]  #
#                                            [ Updated: 2023-10-19 | 20:47 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The installer of GitPy. Install itself and its dependencies                #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is the installer of GitPy
"""


import hashlib
import os
import platform
import shutil
from distutils.dir_util import copy_tree

import pkg_resources
import toml
import yaml

import gitpy.configs.variables as variables
from gitpy.utils.based_distro import detect_based_distro
from gitpy.utils.check_path import check_folder_path
from gitpy.utils.colors import Color
from gitpy.utils.env_var import set_env_var
from gitpy.utils.exit_tool import exit_tool
from gitpy.utils.generate_bin_file import create_bin_file
from gitpy.utils.git_repo import GitRepo
from gitpy.utils.internet_check import internet_check
from gitpy.utils.process import Process


class Installer:
    """The installer of GitPy"""

    install_path = variables.DEFAULT_INSTALL_PATH
    bin_path = variables.BIN_PATH
    temp_path = variables.INSTALL_TEMP_PATH
    gitpy_install_path_env_var_name = variables.GITPY_PATH_ENV_VAR_NAME
    gitpy_install_path_env_var_value = variables.GITPY_PATH_ENV_VAR_DEFAULT_VALUE
    repo_clone_url = variables.REPO_CLONE_URL
    repo_master_branch = variables.REPO_MASTER_BRANCH
    repo_develop_branch = variables.REPO_DEVELOP_BRANCH
    program_name = variables.PROGRAM_NAME
    verbose = variables.OPTION_VERBOSE

    # get the user who run with sudo
    # sudo_user = os.getenv("SUDO_USER")

    def __init__(self, args: object) -> None:
        """Make some checks before the installation.

        Arguments:
            args (object): The arguments of the command.
        """

        try:
            # Check if the user's platform is a Linux machine or not
            if platform.system() != "Linux":
                message = "  {!} You tried to run GitPy on a non-linux machine!\n  {*} GitPy can be run only on a Linux kernel."
                exit_tool(status=1, message=Color.pl(message))

            else:
                # Check if the user is root or not
                if os.getuid() != 0:
                    message = (
                        "  {!} The GitPy Installer must be run as root.\n  {*} Re-run with sudo or switch to root user."
                    )
                    exit_tool(status=1, message=Color.pl(message))

                else:
                    # Distro check
                    if detect_based_distro() == "Arch":
                        self.based_distro = "Arch"
                        self.packet_manager = "pacman"

                    elif detect_based_distro() == "Debian":
                        self.based_distro = "Debian"
                        self.packet_manager = "apt"

                    else:
                        message = "  {!} You're not running Arch or Debian variant.\n  {*} GitPy can only run on Arch or Debian based distros."
                        exit_tool(status=1, message=Color.pl(message))

            if args.skip_update:
                self.update_system_skiped = " (Skipped)"

            else:
                self.update_system_skiped = ""

            if args.path:
                self.install_path = "".join(args.path).strip()
                if args.absolute_path:
                    self.install_path = check_folder_path(
                        folder_path=self.install_path,
                        folder_name=self.program_name,
                        mode="normal",
                    )

                else:
                    self.install_path = check_folder_path(
                        folder_path=self.install_path,
                        folder_name=self.program_name,
                        mode="finish_with",
                    )

            if self.verbose >= 1:
                Color.pl("  {*} Verbosity level: %s" % self.verbose)

                if self.verbose == 1:
                    Color.pl("   {G}└──{W} Verbose level 1 ({C}Blue color{W}) : {&}")

                if self.verbose == 2:
                    Color.pl("   {G}├──{W} Verbose level 1 ({C}Blue color{W})        : {&}")
                    Color.pl(
                        "   {G}└──{W} Verbose level 2 ({W}{bold}stdout{W} and {R}stderr{W}) : {W}{D}[{W}{bold}stdout{W}{D}]{W} {D}[{W}{R}stderr{W}{D}]{W}"
                    )

                if self.verbose >= 3:
                    Color.pl("   {G}├──{W} Verbose level 1 ({C}Blue color{W})        : {&}")
                    Color.pl(
                        "   {G}├──{W} Verbose level 2 ({W}{bold}stdout{W} and {R}stderr{W}) : {W}{D}[{W}{bold}stdout{W}{D}]{W} {D}[{W}{R}stderr{W}{D}]{W}"
                    )
                    Color.pl("   {G}└──{W} Verbose level 3 ({O}{bold}Yellow color{W})      : {§}")

            Color.clear_entire_line()
            Color.p("  {D}[{W}{G}-{W}{D}]{W} Checking for internet connection... ")

            has_internet, status_code = internet_check()

            if has_internet is True and status_code == 200:
                status = "  {+} Checking for internet connection... {G}connected{W}\n"

            else:
                message = "  {+R} Checking for internet connection... {R}not connected{W}.\n  {!} No Internet connection found.\n  {*} Please check if you are connected to the Internet and retry.\n"
                Color.clear_entire_line()
                exit_tool(status=1, message=Color.p(message))

            Color.clear_entire_line()
            Color.p(status)

            Color.p("  {-} Checking if the GitPy's repository are reachable or not...")

            # Check if the GitPy repository on GitHub are reachable or not
            error_code, reachable, web_status_code = GitRepo.is_reachable(repo_url=self.repo_clone_url)

            if error_code != 0:
                if reachable is not True:
                    Color.clear_entire_line()
                    Color.pl("  {+R} Checking if the GitPy's repository are reachable or not... {R}error{W}")
                    message = (
                        "  {!} The GitPy's repository is not reachable.\n   {R}└──{W} Web status code: {R}%s{W}\n  {*} Maybe the repository went private or the URL has changed. If it is the case, please contact me (use {G}gitpy info{W} for my contacts)."
                        % web_status_code
                    )
                    exit_tool(status=1, message=Color.pl(message))

                else:
                    Color.clear_entire_line()
                    Color.pl("  {+R} Checking if the GitPy's repository are reachable or not... {R}error{W}")
                    message = (
                        "  {!} An error occurred while checking if the GitPy's repository is reachable.\n   {R}└──{W} Web status code: {R}%s{W}"
                        % web_status_code
                    )
                    exit_tool(status=1, message=Color.pl(message))

            Color.clear_entire_line()
            Color.pl("  {+} Checking if the GitPy's repository are reachable or not... {G}reachable{W}  ")

            self.installation(args=args)

        except KeyboardInterrupt:
            message = "\n  {*} Aborted"
            # Exit and removing the python cache
            exit_tool(status=1, message=Color.pl(message))

    def installation(self, args: object) -> None:
        """Installation process of GitPy

        Arguments:
            args (object): The arguments of the command.
        """
        try:
            # The list of packages that will be installed by the  system packet manager.
            # Get all dependencies of the project from the settings.py and put them in a list

            if self.based_distro == "Arch":
                dependencies_os = variables.ARCH_PACKAGE_LIST

            elif self.based_distro == "Debian":
                dependencies_os = variables.DEBIAN_PACKAGE_LIST

            dependencies_list = []
            for package in pkg_resources.parse_requirements(sorted(dependencies_os)):
                dependencies_list.append(str(package))

            if args.quiet:
                if self.based_distro == "Arch":
                    Process.call(
                        "pacman -Syy",
                        shell=True,
                    )

                elif self.based_distro == "Debian":
                    Process.call(
                        "apt update",
                        shell=True,
                    )

                # Tools installation
                # TODO: Check if the version installed are lower than the required one. If it is the case, update the tool.
                if self.based_distro == "Arch":
                    for package_name in sorted(variables.ARCH_PACKAGE_LIST):
                        if Process.exists(program=package_name):
                            continue

                        else:
                            Process.call(
                                "pacman -S --noconfirm %s" % package_name,
                                shell=False,
                            )

                elif self.based_distro == "Debian":
                    for package_name in sorted(variables.DEBIAN_PACKAGE_LIST):
                        if Process.exists(program=package_name):
                            continue

                        else:
                            Process.call(
                                "apt install -y %s" % package_name,
                                shell=True,
                            )

                # Detect if the install path folder have files in it.
                install_folder_exist = False
                if os.path.isdir(self.install_path):
                    install_folder_exist = True
                    if os.listdir(self.install_path) != []:
                        shutil.rmtree(self.install_path)

                # Create the destination folder
                if install_folder_exist is False:
                    os.makedirs(self.install_path, mode=0o755)

                if not args.offline:
                    # Detect if the temp path folder exist.
                    if os.path.isdir(self.temp_path):
                        shutil.rmtree(self.temp_path)
                    # Remake it
                    os.makedirs(self.temp_path, mode=0o755)

                    # Clone the repository
                    GitRepo.clone(
                        repo_url=self.repo_clone_url,
                        destination_folder=self.temp_path,
                    )

                    # Copy the files
                    copy_tree(
                        os.path.join(self.temp_path),
                        self.install_path,
                    )

                    # Remove the temporary folder
                    shutil.rmtree(self.temp_path)

                else:
                    # Check if the hash of the file "hashes_of_all_files.yml" match with the hash in the "hashes_of_all_files.yml.hash" file using hashlib

                    # First check if the "hashes_of_all_files.yml" file that contains all the hashes are the correct one
                    # by checking the hash of the "hashes_of_all_files.yml" file with the hash in the "hashes_of_all_files.yml.hash" file
                    with open("%s/gitpy/hashes/hashes_of_all_files.yml" % variables.CWD, "rb") as f:
                        file_hash = hashlib.sha3_512(f.read()).hexdigest()
                        with open("%s/gitpy/hashes/hashes_of_all_files.yml.hash" % variables.CWD, "r") as file:
                            hashes_of_hashes_of_all_files_file = file.read()

                        if file_hash != hashes_of_hashes_of_all_files_file:
                            Color.clear_entire_line()
                            message = '  {!} The hash of the "hashes_of_all_files.yml" file does not match the custom hash.\n  {*} You must re-clone the repository to install GitPy correctly.'
                            exit_tool(status=1, message=Color.pl(message))

                    with open("%s/gitpy/hashes/hashes_of_all_files.yml" % variables.CWD, "r") as f:
                        saved_hashes = yaml.safe_load(f)["hashes"]

                    not_correct_hash_files = []
                    not_exist_files = []

                    excluded_folders = [".chglog", ".git", ".github", ".venv", ".vscode", "tests"]
                    for root, dirs, files in os.walk("."):
                        dirs[:] = [d for d in dirs if d not in excluded_folders]
                        for name in files:
                            if (
                                not name.endswith(".pyc")
                                and not name.endswith(".pyo")
                                and not name.endswith(".pyd")
                                and name != "hashes_of_all_files.yml"
                                and name != "hashes_of_all_files.yml.hash"
                                and name != ".gitignore"
                                and name != ".gitattributes"
                            ):
                                file_path = os.path.join(root, name)
                                with open(file_path, "rb") as file:
                                    file_hash = hashlib.sha3_512(file.read()).hexdigest()
                                    # Remove the '.' before the '/' in the file path
                                    file_path = file_path[2:] if file_path.startswith("./") else file_path
                                    if file_path not in saved_hashes or file_hash != saved_hashes[file_path]:
                                        if os.path.exists(file_path):
                                            not_correct_hash_files.append(file_path)
                                        else:
                                            not_exist_files.append(file_path)

                    if len(not_exist_files) > 0:
                        Color.clear_entire_line()
                        Color.pl("  {+R} Checking the integrity of the files... {R}error{W}")
                        message = "  {!} Some files are missing.\n  {*} You must re-clone the repository to install GitPy correctly."
                        exit_tool(status=1, message=Color.pl(message))

                    elif len(not_correct_hash_files) > 0:
                        Color.clear_entire_line()
                        Color.pl("  {+R} Checking the integrity of the files... {R}error{W}")
                        message = "  {!} Some files have been modified and are not the latest version.\n  {*} You must re-clone the repository to install GitPy correctly."
                        exit_tool(status=1, message=Color.pl(message))

                    # Copy the files

                    copy_tree(
                        os.path.join(variables.CWD),
                        self.install_path,
                    )

                # If a file called 'gitpy' already exist in /usr/bin, ask the user if he want to remove it or not
                if os.path.isfile(self.bin_path + "/gitpy"):
                    os.remove(self.bin_path + "/gitpy")

                # Create the command 'gitpy' in /usr/bin/
                with open(self.bin_path + "/gitpy", "x") as gitpy_file:
                    gitpy_file.write(create_bin_file(path=self.install_path))

                # Create the virtualenv using Poetry
                # Go to the install folder
                os.chdir(self.install_path)
                # Create the virtualenv
                Process.call(
                    "poetry config virtualenvs.in-project true",
                    new_line_before=True,
                )
                Process.call(
                    "poetry install --compile",
                )

                # Apply chmod to the new files.
                Process.call(
                    "chmod 755 %s/gitpy" % self.bin_path,
                    shell=True,
                    new_line_before=True,
                )
                Process.call(
                    "chmod 755 -R %s/*" % self.install_path,
                    shell=True,
                )

                # Create the GITPY_INSTALL_PATH environment variable
                set_env_var(
                    var_name=self.gitpy_install_path_env_var_name,
                    var_value=self.gitpy_install_path_env_var_value,
                )

                # That's all folks! :)

            else:
                infobox = """  {*} {bold}This installer will{W}:
                        \r     {D}[{W}{LL}1{W}{D}]{W} Update your system.%s
                        \r     {D}[{W}{LL}2{W}{D}]{W} Install the SPM dependencies of GitPy.
                        \r      {LL}└──{W} System packet manager: {G}%s{W}""" % (
                    self.update_system_skiped,
                    self.packet_manager,
                )

                # Add the system dependencies to the infobox
                number_of_dependencies = len(dependencies_list)
                dependencies_counter = 0
                for package in dependencies_list:
                    if dependencies_counter != number_of_dependencies - 1:
                        infobox += "\n\r          {LL}├──{W} %s" % package

                    else:
                        infobox += "\n\r          {LL}└──{W} %s" % package

                    dependencies_counter += 1

                infobox += """
                        \r     {D}[{W}{LL}3{W}{D}]{W} Install GitPy in {C}%s{W}.
                        \r     {D}[{W}{LL}4{W}{D}]{W} Create the Python3 virtualenv in {C}%s{W} using Poetry.
                        \r      {LL}├──{W} Python %s virtualenv.
                        \r      {LL}└──{W} Poetry will install (PyPI package) in the virtual env.:""" % (
                    self.install_path,
                    self.install_path,
                    variables.PYTHON_TAG_VERSION,
                )

                # Add the Poetry dependencies to the infobox
                dependencies_counter = 0
                with open("pyproject.toml", "r") as pypro:
                    toml_data = toml.load(pypro)
                    dependencies = toml_data["tool"]["poetry"]["dependencies"]
                    number_of_dependencies = len(dependencies) - 1  # -1 because "python" is not a PyPI package
                    max_package_length = max(len(package) for package in dependencies.keys())

                    for package, version in dependencies.items():
                        if package == "python":
                            continue

                        if dependencies_counter != number_of_dependencies - 1:
                            infobox += "\n\r          {LL}├──{W} %s  ->  %s" % (
                                package.ljust(max_package_length),
                                version,
                            )

                        else:
                            infobox += "\n\r          {LL}└──{W} %s  ->  %s" % (
                                package.ljust(max_package_length),
                                version,
                            )

                        dependencies_counter += 1

                infobox += (
                    """\n\r     {D}[{W}{LL}5{W}{D}]{W} Create the command {G}gitpy{W} in {C}%s{W} to call GitPy everywhere."""
                    % self.bin_path
                )

                Color.pl(infobox)

                if args.no_confirm is True:
                    Color.pl("  {?} Do you want to continue? [Y/n]: y")
                    start_install = "y"

                else:
                    start_install = input(Color.s("  {?} Do you want to continue? [Y/n]: "))

                if not start_install or start_install.lower()[0] == "y":
                    try:
                        # System update
                        if args.skip_update:
                            Color.pl("  {*} System update skipped.")

                        else:
                            Color.p("  {-} Updating your system...")
                            if self.based_distro == "Arch":
                                Process.call(
                                    "pacman -Syy",
                                    shell=True,
                                    new_line_before=True,
                                )

                            elif self.based_distro == "Debian":
                                Process.call(
                                    "apt update",
                                    shell=True,
                                    new_line_before=True,
                                )

                            Color.clear_entire_line()
                            Color.p("  {+} Updating your system... {G}done{W}\n")

                        # Tools installation
                        # TODO: Check if the version installed are lower than the required one. If it is the case, update the tool.

                        if self.based_distro == "Arch":
                            for package_name in sorted(variables.ARCH_PACKAGE_LIST):
                                if Process.exists(program=package_name):
                                    Color.pl("  {*} The package {bold}%s{W} are already installed." % package_name)

                                else:
                                    Color.p("  {-} Installing {bold}%s{W} package..." % package_name)

                                    Process.call(
                                        "pacman -S --noconfirm %s" % package_name,
                                        shell=False,
                                        new_line_before=True,
                                    )

                                    Color.clear_entire_line()
                                    Color.p("  {+} Installing {bold}%s{W} package... {G}done{W}\n" % package_name)

                        elif self.based_distro == "Debian":
                            for package_name in sorted(variables.DEBIAN_PACKAGE_LIST):
                                if Process.exists(program=package_name):
                                    Color.pl("  {*} The package {bold}%s{W} are already installed." % package_name)

                                else:
                                    Color.p("  {-} Installing {bold}%s{W} package..." % package_name)

                                    Process.call(
                                        "apt install -y %s" % package_name,
                                        shell=True,
                                        new_line_before=True,
                                    )

                                    Color.clear_entire_line()
                                    Color.p("  {+} Installing {bold}%s{W} package... {G}done{W}\n" % package_name)

                        ##########################################################################################

                        # Detect if the install path folder have files in it.
                        install_folder_exist = False
                        if os.path.isdir(self.install_path):
                            install_folder_exist = True
                            if os.listdir(self.install_path) != []:
                                Color.pl("  {$} The folder {C}%s{W} is not empty." % self.install_path)

                                if args.no_confirm:
                                    Color.pl("  {?} Do you want to remove it? [Y/n]: y")
                                    continue_install = "y"

                                else:
                                    continue_install = input(Color.s("  {?} Do you want to remove it? [Y/n]: "))

                                if not continue_install or continue_install.lower()[0] == "y":
                                    Color.p("  {-} Removing {C}%s{W}..." % self.install_path)

                                    shutil.rmtree(self.install_path)

                                    Color.clear_entire_line()
                                    Color.p("  {+} Removing {C}%s{W}... {G}done{W}\n" % self.install_path)

                                else:
                                    message = "  {!} You must remove the current files by yourself for continue the install process or choose a another path to install GitPy!"
                                    exit_tool(status=1, message=Color.pl(message))

                        if os.path.isdir(self.temp_path):
                            Color.p("  {-} GitPy's temporary folder found. Removing it...")

                            shutil.rmtree(self.temp_path)

                            Color.clear_entire_line()
                            Color.p("  {+} GitPy's temporary folder found. Removing it... {G}done{W}\n")

                        # Create the destination and temporary folders
                        if install_folder_exist is False:
                            Color.p("  {-} Create the install folder ({C}%s{W})" % self.install_path)

                            os.makedirs(self.install_path, mode=0o755)

                            Color.clear_entire_line()
                            Color.p("  {+} Create the install folder ({C}%s{W})... {G}done{W}\n" % self.install_path)

                        Color.p("  {-} Create the temporary folder ({C}%s{W})..." % self.temp_path)

                        os.makedirs(self.temp_path, mode=0o755)

                        Color.clear_entire_line()
                        Color.p("  {+} Create the temporary folder ({C}%s{W})... {G}done{W}\n" % self.temp_path)

                        if not args.offline:
                            # Clone the repository
                            Color.p("  {-} Cloning the GitPy repository in the temporary folder...")

                            GitRepo.clone(
                                repo_url=self.repo_clone_url,
                                destination_folder=self.temp_path,
                            )

                            Color.clear_entire_line()
                            Color.pl("  {+} Cloning the GitPy repository in the temporary folder... {G}done{W}")

                            # Copy the files
                            Color.p(
                                "  {-} Copying the files ({C}%s{W} -> {C}%s{W})..."
                                % (self.temp_path, self.install_path)
                            )

                            copy_tree(
                                os.path.join(self.temp_path),
                                self.install_path,
                            )

                            Color.clear_entire_line()
                            Color.pl(
                                "  {+} Copying the files (from {C}%s{W} -> {C}%s{W})... {G}done{W}"
                                % (self.temp_path, self.install_path)
                            )

                            # Remove the temporary folder
                            Color.p("  {-} Removing the temporary folder...")

                            shutil.rmtree(self.temp_path)

                            Color.clear_entire_line()
                            Color.p("  {+} Removing the temporary folder... {G}done{W}\n")

                        else:
                            # Check if the hash of the file "hashes_of_all_files.yml" match with the hash in the "hashes_of_all_files.yml.hash" file using hashlib
                            Color.p("  {-} Checking the integrity of the files...")

                            # First check if the "hashes_of_all_files.yml" file that contains all the hashes are the correct one
                            # by checking the hash of the "hashes_of_all_files.yml" file with the hash in the "hashes_of_all_files.yml.hash" file
                            with open("%s/gitpy/hashes/hashes_of_all_files.yml" % variables.CWD, "rb") as f:
                                file_hash = hashlib.sha3_512(f.read()).hexdigest()
                                with open("%s/gitpy/hashes/hashes_of_all_files.yml.hash" % variables.CWD, "r") as file:
                                    hashes_of_hashes_of_all_files_file = file.read()

                                if file_hash != hashes_of_hashes_of_all_files_file:
                                    Color.clear_entire_line()
                                    message = '  {!} The hash of the "hashes_of_all_files.yml" file does not match the custom hash.\n  {*} You must re-clone the repository to install GitPy correctly.'
                                    exit_tool(status=1, message=Color.pl(message))

                            with open("%s/gitpy/hashes/hashes_of_all_files.yml" % variables.CWD, "r") as f:
                                saved_hashes = yaml.safe_load(f)["hashes"]

                            not_correct_hash_files = []
                            not_exist_files = []

                            excluded_folders = [".chglog", ".git", ".github", ".venv", ".vscode", "tests"]
                            for root, dirs, files in os.walk("."):
                                dirs[:] = [d for d in dirs if d not in excluded_folders]
                                for name in files:
                                    if (
                                        not name.endswith(".pyc")
                                        and not name.endswith(".pyo")
                                        and not name.endswith(".pyd")
                                        and name != "hashes_of_all_files.yml"
                                        and name != "hashes_of_all_files.yml.hash"
                                        and name != ".gitignore"
                                        and name != ".gitattributes"
                                    ):
                                        file_path = os.path.join(root, name)
                                        with open(file_path, "rb") as file:
                                            file_hash = hashlib.sha3_512(file.read()).hexdigest()
                                            # Remove the '.' before the '/' in the file path
                                            file_path = file_path[2:] if file_path.startswith("./") else file_path
                                            if file_path not in saved_hashes or file_hash != saved_hashes[file_path]:
                                                if os.path.exists(file_path):
                                                    not_correct_hash_files.append(file_path)
                                                else:
                                                    not_exist_files.append(file_path)

                            if len(not_exist_files) > 0:
                                Color.clear_entire_line()
                                Color.pl("  {+R} Checking the integrity of the files... {R}error{W}")
                                message = "  {!} Some files are missing.\n  {*} You must re-clone the repository to install GitPy correctly."
                                exit_tool(status=1, message=Color.pl(message))

                            elif len(not_correct_hash_files) > 0:
                                Color.clear_entire_line()
                                Color.pl("  {+R} Checking the integrity of the files... {R}error{W}")
                                message = "  {!} Some files have been modified and are not the latest version.\n  {*} You must re-clone the repository to install GitPy correctly."
                                exit_tool(status=1, message=Color.pl(message))

                            else:
                                Color.clear_entire_line()
                                Color.pl("  {+} Checking the integrity of the files... {G}done{W}")

                            # Copy the files
                            Color.p("  {-} Copying the files...")

                            copy_tree(
                                os.path.join(variables.CWD),
                                self.install_path,
                            )

                            Color.clear_entire_line()
                            Color.pl("  {+} Copying the files... {G}done{W}")

                        # If a file called 'gitpy' already exist in /usr/bin, ask the user if he want to remove it or not
                        if os.path.isfile(self.bin_path + "/gitpy"):
                            Color.pl("  {$} A file also called {G}gitpy{W} was found in {C}/usr/bin{W}.")
                            if args.no_confirm is True:
                                Color.pl("  {?} Do you want to remove it? [Y/n]: y")
                                remove_gitpy_bin = "y"

                            else:
                                remove_gitpy_bin = input(Color.s("  {?} Do you want to remove it? [Y/n]: "))

                            if not remove_gitpy_bin or remove_gitpy_bin.lower()[0] == "y":
                                Color.p("  {-} Removing the current {C}gitpy{W} command file...")

                                os.remove(self.bin_path + "/gitpy")

                                Color.clear_entire_line()
                                Color.pl("  {+} Removing the current {C}gitpy{W} command file... {G}done{W}")

                            else:
                                message = "  {!} You must remove the current file by yourself for continue the install process!"
                                exit_tool(status=1, message=Color.pl(message))

                        # Create the command 'gitpy' in /usr/bin/
                        Color.p("  {-} Create the {G}gitpy{W} command into {C}%s{W}..." % self.bin_path)

                        with open(self.bin_path + "/gitpy", "x") as gitpy_file:
                            gitpy_file.write(create_bin_file(path=self.install_path))

                        Color.clear_entire_line()
                        Color.pl("  {+} Create the {G}gitpy{W} command into {C}%s{W}... {G}done{W}" % self.bin_path)

                        # Create the virtualenv using Poetry
                        Color.p("  {-} Create the virtualenv in install folder using Poetry...")

                        # Go to the install folder
                        os.chdir(self.install_path)
                        # Create the virtualenv
                        Process.call(
                            "poetry config virtualenvs.in-project true",
                            new_line_before=True,
                        )
                        Process.call(
                            "poetry install --compile",
                        )

                        Color.clear_entire_line()
                        Color.pl("  {+} Create the virtualenv in install folder using Poetry... {G}done{W}")

                        Color.p("  {-} Apply {G}chmod{W} to the new files...")

                        Process.call(
                            "chmod 755 %s/gitpy" % self.bin_path,
                            shell=True,
                            new_line_before=True,
                        )
                        Process.call(
                            "chmod 755 -R %s/*" % self.install_path,
                            shell=True,
                        )

                        Color.clear_entire_line()
                        Color.pl("  {+} Apply {G}chmod 755{W} rights to the new files... {G}done{W}")

                        Color.p(
                            "  {*} Create the {C}{bold}%s{W} environment variable..."
                            % self.gitpy_install_path_env_var_name
                        )

                        set_env_var(
                            var_name=self.gitpy_install_path_env_var_name,
                            var_value=self.gitpy_install_path_env_var_value,
                        )

                        Color.clear_entire_line()
                        Color.pl(
                            "  {+} Create the {C}{bold}%s{W} environment variable... {G}done{W}"
                            % self.gitpy_install_path_env_var_name
                        )

                        Color.pl(
                            "  {+} GitPy is now successfully installed on your system! You can now use the command {G}gitpy{W} everywhere."
                        )

                        Color.pl("  {*} You need to restart your machine to apply the new environment variable.")

                    except KeyboardInterrupt:
                        message = "\n  {!} Installation process interrupted.\n  {*} You must re-run the installation process to install GitPy correctly."
                        # Exit and removing the python cache
                        exit_tool(status=1, message=Color.pl(message))

                else:
                    message = "  {*} Aborted"
                    # Exit and removing the python cache
                    exit_tool(status=1, message=Color.pl(message))

        except KeyboardInterrupt:
            message = "\n  {*} Aborted"
            # Exit and removing the python cache
            exit_tool(status=1, message=Color.pl(message))


def entry_point(args):
    Installer(args=args)

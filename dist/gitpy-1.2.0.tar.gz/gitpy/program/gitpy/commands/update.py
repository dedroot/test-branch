#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ updater.py                     [ Created: 2023-03-21 | 08:32 ]  #
#                                            [ Updated: 2023-10-10 | 17:39 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The updater of GitPy for download and install the latest                   #
#  version of GitPy from its GitHub repository.                               #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is the updater of GitPy. It will update GitPy and its dependencies (if needed).
"""


import os
import platform
import sys

import gitpy.configs.variables as variables
from gitpy.utils.based_distro import detect_based_distro
from gitpy.utils.colors import Color
from gitpy.utils.env_var import set_env_var
from gitpy.utils.exit_tool import exit_tool
from gitpy.utils.generate_bin_file import create_bin_file
from gitpy.utils.git_repo import GitRepo
from gitpy.utils.internet_check import internet_check
from gitpy.utils.process import Process


class Updater:
    """
    The updater of GitPy.
    """

    try:
        install_path = os.environ[variables.GITPY_PATH_ENV_VAR_NAME]
        gitpy_installed = True
    except KeyError:
        gitpy_installed = False

    bin_path = variables.BIN_PATH
    temp_path = variables.UPDATE_TEMP_PATH
    gitpy_install_path_env_var_name = variables.GITPY_PATH_ENV_VAR_NAME
    gitpy_install_path_env_var_value = variables.GITPY_PATH_ENV_VAR_DEFAULT_VALUE
    repo_clone_url = variables.REPO_CLONE_URL
    repo_master_branch = variables.REPO_MASTER_BRANCH
    repo_develop_branch = variables.REPO_DEVELOP_BRANCH
    program_name = variables.PROGRAM_NAME
    verbose = variables.OPTION_VERBOSE

    def __init__(self, args: object) -> None:
        """Make some checks before the update.

        Arguments:
            args (object): The CLI arguments passed to the updater.
        """

        try:
            # Check if the user's platform is a Linux machine or not
            if platform.system() != "Linux":
                message = "  {!} You tried to run GitPy on a non-linux machine!\n  {*} GitPy can be run only on a Linux kernel."
                exit_tool(status=1, message=Color.pl(message))

            else:
                # Check if the user is root or not
                if os.getuid() != 0:
                    message = (
                        "  {!} The GitPy Updater must be run as root.\n  {*} Re-run with sudo or switch to root user."
                    )
                    exit_tool(status=1, message=Color.pl(message))

                else:
                    # Distro check
                    if detect_based_distro() == "Arch":
                        self.based_distro = "Arch"
                        self.packet_manager = "pacman"

                    elif detect_based_distro() == "Debian":
                        self.based_distro = "Debian"
                        self.packet_manager = "apt"

                    else:
                        message = "  {!} You're not running Arch or Debian variant.\n  {*} GitPy can only run on Arch or Debian based distros."
                        exit_tool(status=1, message=Color.pl(message))

            if self.gitpy_installed is not False:
                message = "  {!} GitPy is not installed on your system!"
                exit_tool(status=1, message=Color.pl(message))

            if self.verbose >= 1:
                Color.pl("  {*} Verbosity level: %s" % self.verbose)

                if self.verbose == 1:
                    Color.pl("   {G}└──{W} Verbose level 1 ({C}Blue color{W}) : {&}")

                if self.verbose == 2:
                    Color.pl("   {G}├──{W} Verbose level 1 ({C}Blue color{W})        : {&}")
                    Color.pl(
                        "   {G}└──{W} Verbose level 2 ({W}{bold}stdout{W} and {R}stderr{W}) : {W}{D}[{W}{bold}stdout{W}{D}]{W} {D}[{W}{R}stderr{W}{D}]{W}"
                    )

                if self.verbose >= 3:
                    Color.pl("   {G}├──{W} Verbose level 1 ({C}Blue color{W})        : {&}")
                    Color.pl(
                        "   {G}├──{W} Verbose level 2 ({W}{bold}stdout{W} and {R}stderr{W}) : {W}{D}[{W}{bold}stdout{W}{D}]{W} {D}[{W}{R}stderr{W}{D}]{W}"
                    )
                    Color.pl("   {G}└──{W} Verbose level 3 ({O}{bold}Yellow color{W})      : {§}")

            Color.clear_entire_line()
            Color.p("  {D}[{W}{G}-{W}{D}]{W} Checking for internet connection... ")

            has_internet, status_code = internet_check()

            if has_internet is True and status_code == 200:
                status = "  {+} Checking for internet connection... {G}connected{W}\n"

            else:
                message = "  {+R} Checking for internet connection... {R}not connected{W}.\n  {!} No Internet connection found.\n  {*} Please check if you are connected to the Internet and retry.\n"
                Color.clear_entire_line()
                exit_tool(status=1, message=Color.p(message))

            Color.clear_entire_line()
            Color.p(status)

            Color.p("  {-} Checking if the GitPy's repository are reachable or not...")

            # Check if the GitPy repository on GitHub are reachable or not
            error_code, reachable, web_status_code = GitRepo.is_reachable(repo_url=self.repo_clone_url)

            if error_code != 0:
                if reachable is not True:
                    Color.clear_entire_line()
                    Color.pl("  {+R} Checking if the GitPy's repository are reachable or not... {R}error{W}")
                    message = (
                        "  {!} The GitPy's repository is not reachable.\n   {R}└──{W} Web status code: {R}%s{W}\n  {*} Maybe the repository went private or the URL has changed. If it is the case, please contact me (use {G}gitpy info{W} for my contacts)."
                        % web_status_code
                    )
                    exit_tool(status=1, message=Color.pl(message))

                else:
                    Color.clear_entire_line()
                    Color.pl("  {+R} Checking if the GitPy's repository are reachable or not... {R}error{W}")
                    message = (
                        "  {!} An error occurred while checking if the GitPy's repository is reachable.\n   {R}└──{W} Web status code: {R}%s{W}"
                        % web_status_code
                    )
                    exit_tool(status=1, message=Color.pl(message))

            Color.clear_entire_line()
            Color.pl("  {+} Checking if the GitPy's repository are reachable or not... {G}reachable{W}  ")

            self.update(args=args)

        except KeyboardInterrupt:
            message = "\n  {*} Aborted"
            # Exit and removing the python cache
            exit_tool(status=1, message=Color.pl(message))

    def update(self, args: object) -> None:
        """The updater process function of GitPy

        Arguments:
            args (object): The arguments of the command.
        """

        try:
            if args.quiet:
                pass
            else:
                infobox = """  {*} {bold}This updater will{W}:
                    \r     {D}[{W}{LL}1{W}{D}]{W} Download the latest version of GitPy in the temporary folder. ({C}%s{W})
                    \r     {D}[{W}{LL}2{W}{D}]{W} Copy the new version of GitPy in the install folder. ({C}%s{W})""" % (
                    self.temp_path,
                    "test",
                )
                Color.pl(infobox)

        except KeyboardInterrupt:
            message = "\n  {*} Aborted"
            # Exit and removing the python cache
            exit_tool(status=1, message=Color.pl(message))


def entry_point(args):
    Updater(args=args)

#!/usr/bin/env python3
# PYZSHCOMPLETE_OK
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ cli_tool.py                    [ Created: 2023-06-19 | 12:52 ]  #
#                                            [ Updated: 2023-06-23 | 14:27 ]  #
# ---[Description & File Language]------------------------------------------- #
#  The CLI tool of GitPy (with options and arguments)                         #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
The CLI tool of gitpy (with options and arguments)
"""


import argparse
import sys
from gettext import gettext as _  # for CustomArgparse

import gitpy.configs.variables as variables
from gitpy.parse import Parse
from gitpy.utils.colors import Color
from gitpy.utils.exit_tool import exit_tool
from gitpy.utils.help_messages import HelpMessages as HM


class GitPyCLI:
    """
    The CLI tool of GitPy (with options and arguments)
    """

    class CustomHelpFormatter(argparse.HelpFormatter):
        """
        Custom help formatter (not in use because it use the
        custom help message in the 'help_messages.py' file)
        """

        def add_usage(self, usage, actions, groups, prefix=None):
            if prefix is None:
                prefix = Color.s("  {*} usage{W}: ")
            return super(GitPyCLI.CustomHelpFormatter, self).add_usage(usage, actions, groups, prefix)

        def _fill_text(self, text, width, indent):
            return "".join(indent + line for line in text.splitlines(keepends=True))

    class CustomArgparse(argparse.ArgumentParser):
        """
        Custom argparse class to override some output methods.
        """

        def format_usage(self):
            formatter = self._get_formatter()
            formatter.add_usage(self.usage, self._actions, self._mutually_exclusive_groups)
            return formatter.format_help()

        def print_usage(self, file=None):
            if file is None:
                file = sys.stdout
            self._print_message(self.format_usage(), file)

        def parse_args(self, args=None, namespace=None):
            args, argv = self.parse_known_args(args, namespace)
            if argv:
                msg = _("unrecognized arguments: %s")
                self.error(msg % " ".join(argv))
            return args

        def parse_intermixed_args(self, args=None, namespace=None):
            args, argv = self.parse_known_intermixed_args(args, namespace)
            if argv:
                msg = _("unrecognized arguments: %s")
                self.error(msg % " ".join(argv))
            return args

        def error(self, message):
            """
            Prints a usage message incorporating the message to stderr and
            exits.

            If you override this in a subclass, it should not return -- it
            should either exit or raise an exception.
            """

            # Tried to make a custom error message for command and option but it doesn't work as I want x)

            # args = {"prog": self.prog, "message": message}
            # argv = list(argv)
            # print(argv)
            # print(args)
            # if "unrecognized arguments" in message or "invalid choice" in message:
            #     if args["prog"] == "gitpy":
            #         Color.pl(HM.CLITool.main_help_msg())
            #         if (
            #             sys.argv[1] not in GitPyCLI.commands_list
            #             and sys.argv[1] not in GitPyCLI.options_list
            #         ):
            #             if sys.argv[1].startswith("-"):
            #                 message = "\n  {!} Option not found: {C}%s{W}" % argv
            #             else:
            #                 message = "\n  {!} Command not found: {C}%s{W}" % argv
            #         exit_tool(status=2, message=(Color.pl(message)))
            #     elif args["prog"] == "gitpy cache":
            #         Color.pl(HM.CLITool.Commands.Cache.cache_arg())
            #         if (
            #             sys.argv[2::] not in GitPyCLI.CacheArgs.commands_list_of_cache
            #             and sys.argv[2::]
            #             not in GitPyCLI.CacheArgs.options_list_of_cache
            #         ):
            #             for arg in argv:
            #                 if arg.startswith("-"):
            #                     message = "\n  {!} Option not found: {C}%s{W}" % argv
            #                 else:
            #                     message = "\n  {!} Command not found: {C}%s{W}" % argv
            #         exit_tool(status=2, message=(Color.pl(message)))
            #     elif args["prog"] == "gitpy cache show":
            #         Color.pl(HM.CLITool.Commands.Cache.show_arg())
            #         if (
            #             sys.argv[3::] not in GitPyCLI.CacheArgs.commands_list_of_show
            #             and sys.argv[3::]
            #             not in GitPyCLI.CacheArgs.commands_list_of_show
            #         ):
            #             if sys.argv[3].startswith("-"):
            #                 message = (
            #                     "\n  {!} Option not found: {C}%s{W}" % sys.argv[3::]
            #                 )
            #             else:
            #                 message = (
            #                     "\n  {!} Command not found: {C}%s{W}" % sys.argv[3::]
            #                 )
            #         exit_tool(status=2, message=(Color.pl(message)))
            #     else:
            #         exit_tool(
            #             status=2,
            #             message=_(
            #                 Color.s("  {!} %(prog)s: error: %(message)s\n") % args
            #             ),
            #         )
            # exit()

            self.print_usage(sys.stderr)
            args = {"prog": self.prog, "message": message}
            message = _(
                Color.s("  {!} %(prog)s: error: %(message)s\n  {*} Try {G}%(prog)s --help{W} for more information.\n")
                % args
            )
            exit_tool(
                status=2,
                message=message,
            )

    cli_wrapper = Parse()
    commands_list = [
        "cache",
        "config",
        "info",
        "install",
        "repo",
        "uninstall",
        "update",
        "version",
    ]
    options_list = ["--help"]

    def __init__(self):
        main = GitPyCLI.CustomArgparse(
            prog="gitpy",
            usage=Color.s("%(prog)s [{underscore}options{W}]..."),
            allow_abbrev=False,
            formatter_class=GitPyCLI.CustomHelpFormatter,
            add_help=False,
        )
        main.add_argument(
            "command",
            nargs="?",
            help="command to run",
            choices=self.commands_list,
        )
        main.add_argument(
            "--help",
            required=False,
            action="store_true",
            help="show this help message and exit or show more help for a option and exit.",
        )

        args = main.parse_args(sys.argv[1:2])

        if args.command == "cache":
            if len(sys.argv) >= 3 and sys.argv[2] == "show":
                self.CacheArgs.show(self)
            elif len(sys.argv) >= 3 and sys.argv[2] == "flush":
                self.CacheArgs.flush(self)
            else:
                self.CacheArgs.cache(self)

        # elif args.command == "cli":
        #     self.cli()

        if args.command == "config":
            if len(sys.argv) >= 3 and sys.argv[2] == "show":
                self.ConfigArgs.show(self)
            elif len(sys.argv) >= 3 and sys.argv[2] == "reset":
                self.ConfigArgs.reset(self)
            else:
                self.ConfigArgs.config(self)

        elif args.command == "info":
            self.info()

        elif args.command == "install":
            self.install()

        elif args.command == "repo":
            if len(sys.argv) >= 3 and sys.argv[2] == "check":
                self.RepoArgs.check(self)
            elif len(sys.argv) >= 3 and sys.argv[2] == "unsub":
                self.RepoArgs.unsub(self)
            elif len(sys.argv) >= 3 and sys.argv[2] == "search":
                self.RepoArgs.search(self)
            else:
                self.RepoArgs.repo(self)

        elif args.command == "uninstall":
            self.uninstall()

        elif args.command == "update":
            if len(sys.argv) >= 3 and sys.argv[2] == "check":
                self.UpdateArgs.check(self)
            else:
                self.UpdateArgs.update(self)

        elif args.command == "version":
            self.version()

        elif not args.command or args.help:
            Color.pl(HM.CLITool.main_help_msg())
            exit_tool(status=0)

    class CacheArgs:
        """
        The "cache" command and its subcommands.
        The cache command has 2 subcommands:
            - show
            - flush
        """

        commands_list_of_cache = [
            "show",
            "flush",
        ]
        commands_list_of_show = []
        commands_list_of_flush = []

        def cache(self):
            """
            Manipulate the GitPy's config
            """
            config_args = GitPyCLI.CustomArgparse(
                description="Manage the cache of GitPy.",
                prog="gitpy cache",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            config_args.add_argument(
                "command",
                nargs="?",
                help="command to run",
                choices=GitPyCLI.CacheArgs.commands_list_of_cache,
            )
            config_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            args = config_args.parse_args(sys.argv[2::])
            return GitPyCLI.cli_wrapper.ParseCache.parse_cache_args(args=args)

        def show(self):
            """
            Show the cache of GitPy
            """

            show_args = GitPyCLI.CustomArgparse(
                description="Show the cache of GitPy.",
                prog="gitpy cache show",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            show_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            show_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = show_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseCache.parse_show_args(args=args)

        def flush(self):
            """
            Flush the cache of GitPy
            """

            reset_args = GitPyCLI.CustomArgparse(
                description="Flush the cache of GitPy.",
                prog="gitpy cache flush",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            reset_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            reset_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = reset_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseCache.parse_flush_args(args=args)

    class ConfigArgs:
        """
        The "config" command and its subcommands.
        The config command has 2 subcommands:
            - show
            - reset
        """

        commands_list_of_config = [
            "show",
            "reset",
        ]

        def config(self):
            """
            Manipulate the GitPy's config
            """

            config_args = GitPyCLI.CustomArgparse(
                description="Manipulate the GitPy's config.",
                prog="gitpy config",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            config_args.add_argument(
                "command",
                nargs="?",
                help="command to run",
                choices=GitPyCLI.ConfigArgs.commands_list_of_config,
            )
            config_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            args = config_args.parse_args(sys.argv[2::])
            return GitPyCLI.cli_wrapper.ParseConfig.parse_config_args(args=args)

        def show(self):
            """
            Show the content of the GitPy's config file
            """

            show_args = GitPyCLI.CustomArgparse(
                description="Show the content of the GitPy's config file.",
                prog="gitpy config show",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            show_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            show_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = show_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseConfig.parse_show_args(args=args)

        def reset(self):
            """
            Reset the GitPy's config file with the default values
            """

            reset_args = GitPyCLI.CustomArgparse(
                description="Reset the GitPy's config file with the default values.",
                prog="gitpy config reset",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            reset_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            reset_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = reset_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseConfig.parse_reset_args(args=args)

    def info(self):
        """
        Show more information about GitPy
        """

        info_args = GitPyCLI.CustomArgparse(
            description="Show more information about GitPy.",
            prog="gitpy info",
            usage=Color.s("%(prog)s [{underscore}options{W}]..."),
            allow_abbrev=False,
            add_help=False,
            formatter_class=GitPyCLI.CustomHelpFormatter,
        )
        info_args.add_argument(
            "--help",
            action="store_true",
            help="show this help message and exit",
        )
        args = info_args.parse_args(sys.argv[2::])
        return GitPyCLI.cli_wrapper.parse_info_args(args=args)

    def install(self):
        """
        Install GitPy on the system
        """

        install_args = GitPyCLI.CustomArgparse(
            description="Install GitPy on the system",
            prog="gitpy install",
            usage=Color.s("%(prog)s [{underscore}options{W}]..."),
            allow_abbrev=False,
            add_help=False,
            formatter_class=GitPyCLI.CustomHelpFormatter,
        )
        install_args.add_argument(
            "--ab",
            "--absolute-path",
            action="store_true",
            dest="absolute_path",
            help="don't check if the path entered with the --path argument finish with 'gitpy'",
        )
        install_args.add_argument(
            "--help",
            action="store_true",
            help="show this help message and exit",
        )
        install_args.add_argument(
            "--nc",
            "--no-confirm",
            action="store_true",
            dest="no_confirm",
            help='bypass any and all "Are you sure?" messages.',
        )
        install_args.add_argument(
            "--offline",
            action="store_true",
            dest="offline",
            help="install GitPy with the local file already downloaded. By default, the Installer download the latest version from the Git's repository and install it on the machine",
        )
        install_args.add_argument(
            "--path",
            type=str,
            nargs="?",
            const="0",
            metavar="PATH",
            dest="path",
            help="the path where GitPy will be installed (default: %s)" % variables.DEFAULT_INSTALL_PATH,
        )
        install_args.add_argument(
            "--quiet",
            action="store_true",
            help='prevent header from displaying. Warning: bypass any "Are your sure?" message!',
        )
        install_args.add_argument(
            "--su",
            "--skip-update",
            action="store_true",
            dest="skip_update",
            help="skip the system update phase during the installation of GitPy",
        )
        install_args.add_argument(
            "-v",
            action="count",
            default=0,
            dest="verbose",
            help="Verbosity level: 1-3 (default: %(default)s)",
        )
        args = install_args.parse_args(sys.argv[2::])
        return GitPyCLI.cli_wrapper.parse_install_args(args=args)

    class RepoArgs:
        """
        The "repo" command and its subcommands.
        The config command has 2 subcommands:
            - check
            - unsub
            - search
        """

        commands_list_of_repo = [
            "check",
            "unsub",
            "search",
        ]

        def repo(self):
            """
            Manage your subscripted repositories
            """

            repo_args = GitPyCLI.CustomArgparse(
                description="Manage your subscripted repositories.",
                prog="gitpy repo",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            repo_args.add_argument(
                "command",
                nargs="?",
                help="command to run",
                choices=GitPyCLI.RepoArgs.commands_list_of_repo,
            )
            repo_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            args = repo_args.parse_args(sys.argv[2::])
            return GitPyCLI.cli_wrapper.ParseRepo.parse_repo_args(args=args)

        def check(self):
            """
            Check if an subscripted repo have a new version available
            """

            check_args = GitPyCLI.CustomArgparse(
                description="Check if an subscripted repo have a new version available.",
                prog="gitpy repo check",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            check_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            check_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = check_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseRepo.parse_check_args(args=args)

        def unsub(self):
            """
            Unsubscribe to a subscripted repository
            """

            unsub_args = GitPyCLI.CustomArgparse(
                description="Unsubscribe to a subscripted repository.",
                prog="gitpy repo unsub",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            unsub_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            unsub_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = unsub_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseRepo.parse_unsub_args(args=args)

        def search(self):
            """
            Search for a public online Git repository
            """

            search_args = GitPyCLI.CustomArgparse(
                description="Search for a public online Git repository.",
                prog="gitpy repo search",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            search_args.add_argument(
                "-a",
                "--author",
                nargs=1,
                metavar="<AUTHOR>",
                dest="author",
                help="search for a specific author",
            )
            search_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            search_args.add_argument(
                "-l",
                "--language",
                nargs=1,
                metavar="<LANGUAGE>",
                dest="language",
                help="search for a specific language",
            )
            search_args.add_argument(
                "-n",
                "--repo-name",
                nargs=1,
                metavar="<REPO-NAME>",
                dest="repo_name",
                help="what you want to search",
            )
            search_args.add_argument(
                "-h",
                "--host",
                nargs=1,
                default="github",
                choices=["github", "gitlab"],
                dest="test",
                help="on what you want to search (default: %(default)s)",
            )
            search_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = search_args.parse_args(sys.argv[3:])
            return GitPyCLI.cli_wrapper.ParseRepo.parse_search_args(args=args)

    def uninstall(self):
        """
        Uninstall GitPy from your system
        """

        uninstall_args = GitPyCLI.CustomArgparse(
            description="Uninstall GitPy from your system.",
            prog="gitpy uninstall",
            usage=Color.s("%(prog)s [{underscore}options{W}]..."),
            allow_abbrev=False,
            add_help=False,
            formatter_class=GitPyCLI.CustomHelpFormatter,
        )
        uninstall_args.add_argument(
            "--help",
            action="store_true",
            dest="help",
            help="show this help message and exit",
        )
        uninstall_args.add_argument(
            "--nc",
            "--no-confirm",
            action="store_true",
            dest="no_confirm",
            help='bypass any and all "Are you sure?" messages.',
        )
        uninstall_args.add_argument(
            "--quiet",
            action="store_true",
            dest="quiet",
            help='prevent header from displaying. Warning: bypass any "Are your sure?" message!',
        )
        uninstall_args.add_argument(
            "-v",
            action="count",
            default=0,
            dest="verbose",
            help="Verbosity level: 1-3 (default: %(default)s)",
        )
        args = uninstall_args.parse_args(sys.argv[2:])
        return GitPyCLI.cli_wrapper.parse_uninstall_args(args=args)

    class UpdateArgs:
        """
        The "update" command and its subcommands.
        The config command has 1 subcommand:
            - check
        """

        commands_list_of_update = [
            "check",
        ]

        def update(self):
            """
            Update your GitPy instance to the latest version.
            """

            update_args = GitPyCLI.CustomArgparse(
                description="Update your GitPy instance to the latest version.",
                prog="gitpy update",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            update_args.add_argument(
                "command",
                nargs="?",
                help="command to run",
                choices=GitPyCLI.UpdateArgs.commands_list_of_update,
            )
            update_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            update_args.add_argument(
                "--fu",
                "--force-update",
                action="store_true",
                dest="force_update",
                help="update GitPy even if the version on the machine is already the latest",
            )
            update_args.add_argument(
                "--nc",
                "--no-confirm",
                action="store_true",
                dest="no_confirm",
                help='bypass any and all "Are you sure?" messages.',
            )
            update_args.add_argument(
                "--quiet",
                action="store_true",
                dest="quiet",
                help='prevent header from displaying. Warning: bypass any "Are your sure?" message!',
            )
            update_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = update_args.parse_args(sys.argv[2:])
            return GitPyCLI.cli_wrapper.ParseUpdate.parse_update_args(args=args)

        def check(self):
            """
            Check if a new version of GitPy is available
            """

            check_args = GitPyCLI.CustomArgparse(
                description="Check if a new version of GitPy is available.",
                prog="gitpy update check",
                usage=Color.s("%(prog)s [{underscore}options{W}]..."),
                allow_abbrev=False,
                add_help=False,
                formatter_class=GitPyCLI.CustomHelpFormatter,
            )
            check_args.add_argument(
                "--help",
                action="store_true",
                dest="help",
                help="show this help message and exit",
            )
            check_args.add_argument(
                "-v",
                action="count",
                default=0,
                dest="verbose",
                help="Verbosity level: 1-3 (default: %(default)s)",
            )
            args = check_args.parse_args(sys.argv[3::])
            return GitPyCLI.cli_wrapper.ParseUpdate.parse_check_args(args=args)

    def version(self):
        """
        Show program's version and exit
        """

        version_args = GitPyCLI.CustomArgparse(
            description="Show program's version and exit.",
            prog="gitpy version",
            usage=Color.s("%(prog)s [{underscore}options{W}]..."),
            allow_abbrev=False,
            add_help=False,
            formatter_class=GitPyCLI.CustomHelpFormatter,
        )
        version_args.add_argument(
            "--help",
            action="store_true",
            dest="help",
            help="show this help message and exit",
        )
        version_args.add_argument(
            "-v",
            action="count",
            default=0,
            dest="verbose",
            help="Verbosity level: 1-3 (default: %(default)s)",
        )
        args = version_args.parse_args(sys.argv[2:])
        return GitPyCLI.cli_wrapper.parse_version_args(args=args)

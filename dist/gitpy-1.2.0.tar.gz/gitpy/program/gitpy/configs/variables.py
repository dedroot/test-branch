#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ variables.py                   [ Created: 2023-07-21 | 10:03 ]  #
#                                            [ Updated: 2023-11-11 | 18:43 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Variables file of GitPy                                                    #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This module is used to store the variables used by GitPy.
"""


import platform
import sys
from importlib.metadata import version as importlib_eversion

import toml

# Versions
GITPY_ONLINE_VERSION = ""
GITPY_LOCAL_VERSION = "1.0.0.0-dev"
PYTHON_VERSION_FULL = sys.version
PYTHON_TAG_VERSION = platform.python_version()

# GitPy's dependencies list
# Packages list for Arch based distros (pacman)
ARCH_PACKAGE_LIST = [
    "git",
    "curl",
    "wget",
]
# Packages list for Debian based distros (apt (dpkg))
DEBIAN_PACKAGE_LIST = [
    "git",
    "curl",
    "wget",
]

# GitPy's author information
AUTHOR_FULLNAME = "Thomas Pellissier"
AUTHOR_USERNAME = "dedroot"
AUTHOR_DISCORD = "dedroot"
AUTHOR_EMAIL = "thomas.pellissier.pro@proton.me"
AUTHOR_GITHUB = "https://github.com/dedroot"
AUTHOR_TWITTER = "https://twitter.com/dedroot"

# GitPy's repository information
REPO_LICENSE_NAME = "GPL-3.0"
REPO_LICENSE_URL = "https://www.gnu.org/licenses/gpl-3.0.html"
REPO_TYPE = "git"
REPO_PROVIDER = "GitHub"
REPO_URL = "https://github.com/dedroot/gitpy"
REPO_CLONE_URL = "https://github.com/dedroot/gitpy.git"
REPO_CHANGELOG_URL = "https://github.com/dedroot/gitpy/blob/master/CHANGELOG.md"
REPO_ISSUES_URL = "https://github.com/dedroot/gitpy/issues"
REPO_SETTINGS_URL_FROM_MASTER = "https://raw.githubusercontent.com/dedroot/gitpy/master/gitpy/src/configs/settings.py"
REPO_MASTER_BRANCH = "master"
REPO_DEVELOP_BRANCH = "develop"

# GitPy's banner
GITPY_BANNER = """{SB2}{bold}
┌─┐┬┌┬┐┌─┐┬ ┬ {W}{bold}{{W}{D}%s{W}{bold}}{W}{SB2}{bold}
│ ┬│ │ ├─┘└┬┘ {W}{D}by dedroot{W}{SB2}{bold}
└─┘┴ ┴ ┴   ┴  {W}{GR}{underscore}%s{W}""" % (
    GITPY_LOCAL_VERSION,
    REPO_URL,
)

# Name of the tool
PROGRAM_NAME = "gitpy"

# OPTIONS variables
OPTION_VERBOSE = 0
OPTION_QUIET = False
OPTION_SKIP_UPDATE = False
OPTION_OFFLINE_INSTALL = False
OPTION_NON_CONFIRM = False
OPTION_CUSTOM_INSTALL_PATH = None
OPTION_FORCE_UPDATE = False
OPTION_REMOVE_DEPENDENCIES = False

# Path variables
CWD = "."
# Where GitPy is installed by default
DEFAULT_INSTALL_PATH = "/opt/gitpy"
# The bin directory of GitPy
BIN_PATH = "/usr/bin"
# The GitPy installation temporary directory
INSTALL_TEMP_PATH = "/tmp/gitpy_install_tmpfolder"
# The GitPy update temporary directory
UPDATE_TEMP_PATH = "/tmp/gitpy_update_tmpfolder"
# The GitPy config file by default
DEFAULT_GITPY_CONFIG_FILE_PATH = "%s/gitpy/configs/gitpy_config.yml" % DEFAULT_INSTALL_PATH

# Environment variables
GITPY_PATH_ENV_VAR_NAME = "GITPY_INSTALL_PATH"
GITPY_PATH_ENV_VAR_DEFAULT_VALUE = DEFAULT_INSTALL_PATH

# The version's messages for the version command
VERSION_MESSAGE = GITPY_LOCAL_VERSION
VERSION_MESSAGE_VERBOSE2 = "%s %s\nPython %s" % (
    PROGRAM_NAME,
    GITPY_LOCAL_VERSION,
    PYTHON_VERSION_FULL,
)
VERSION_MESSAGE_VERBOSE3 = """GitPy %s

Copyright (C) 2023 Thomas Pellissier.
License GPLv3+: GNU GPL version 3 or later
<http://www.gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.

Originally written by Thomas Pellissier <%s>.
Please send bug reports and questions to <%s>
or open an issue on <%s>.

Python version in virtual environment: 
{SB4}└──{W} Python %s""" % (
    GITPY_LOCAL_VERSION,
    AUTHOR_EMAIL,
    AUTHOR_EMAIL,
    REPO_ISSUES_URL,
    PYTHON_VERSION_FULL,
)
VERSION_MESSAGE_VERBOSE4 = """GitPy %s

Copyright (C) 2023 Thomas Pellissier.
License GPLv3+: GNU GPL version 3 or later
<http://www.gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.

Originally written by Thomas Pellissier <%s>.
Please, for any bug reports and questions, open a issue at <%s>
or send a mail to <%s>.

Python version in virtual environment: 
{SB4}└──{W} Python %s

Dependencies version (PyPI) in virtual environment:""" % (
    GITPY_LOCAL_VERSION,
    AUTHOR_EMAIL,
    REPO_ISSUES_URL,
    AUTHOR_EMAIL,
    PYTHON_VERSION_FULL,
)
# Add the poetry dependencies to VERSION_MESSAGE_VERBOSE4
dependencies_counter = 0
with open("pyproject.toml", "r") as f:
    toml_data = toml.load(f)
    dependencies = toml_data["tool"]["poetry"]["dependencies"]
    number_of_dependencies = len(dependencies) - 1
    max_package_length = max(len(package) for package in dependencies.keys())

    for package, version in dependencies.items():
        if package == "python":
            continue

        if dependencies_counter != number_of_dependencies - 1:
            try:
                version = importlib_eversion(package)

            except ModuleNotFoundError:
                version = "Not found"

            VERSION_MESSAGE_VERBOSE4 += "\n{SB4}├──{W} %s  ->  %s" % (
                package.ljust(max_package_length),
                version,
            )

        else:
            try:
                version = importlib_eversion(package)

            except ModuleNotFoundError:
                version = "Not found"

            VERSION_MESSAGE_VERBOSE4 += "\n{SB4}└──{W} %s  ->  %s" % (
                package.ljust(max_package_length),
                version,
            )

        dependencies_counter += 1

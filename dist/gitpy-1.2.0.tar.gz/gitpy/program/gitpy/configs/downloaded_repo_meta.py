#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ---[Name & Creation/Update Dates]------------------------------------------ #
#  Filename ~ downloaded_repo_meta.py        [ Created: 2023-09-13 | 15:51 ]  #
#                                            [ Updated: 2023-09-13 | 15:52 ]  #
# ---[Description & File Language]------------------------------------------- #
#  Information about the repositories downloaded with GitPy.                  #
#  Language ~ Python3                                                         #
#  Version ~ 1.0.0.0-dev                                                      #
# ---[Authors]--------------------------------------------------------------- #
#  Thomas Pellissier (dedroot)                                                #
# ---[Maintainer]------------------------------------------------------------ #
#  Thomas Pellissier (dedroot)                                                #
# ---[Operating System]------------------------------------------------------ #
#  Developed for Linux distros (for Debian and Arch based, for the moment)    #
# --------------------------------------------------------------------------- #


"""
This files contains the information about the repositories downloaded with GitPy.
"""

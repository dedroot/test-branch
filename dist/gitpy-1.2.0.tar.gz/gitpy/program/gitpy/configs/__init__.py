"""
This folder is used to store all config related files of GitPy.
"""
